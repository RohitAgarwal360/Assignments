//package dat;
import java.util.Scanner;
import dat.circle;
import dat.inter;
import dat.rect;

public class MAIN
{
   public static void main(String args[])
   {
     System.out.println("This is Interface and package ");
     circle objc=new circle();
     float area1=objc.area();
     
     rect objr=new rect();
     float area2=objr.area();
     
     System.out.println("Area of a circle"+area1);
     
     System.out.println("Area of a reactangle"+area2);
    }
 }
     
