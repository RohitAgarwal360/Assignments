package dat;
public interface inter
{
   final static float pi=3.142F;
   public float area();
 }
 
