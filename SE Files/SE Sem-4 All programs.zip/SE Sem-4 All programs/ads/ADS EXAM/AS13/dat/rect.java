package dat;
import dat.inter;
import java.util.Scanner;
public class rect implements inter
{
  public float area()
  {
     System.out.println("Enter the side of a square");
     Scanner sc=new Scanner(System.in);
     float r=sc.nextFloat();
     return (r*r);
   }
 }
