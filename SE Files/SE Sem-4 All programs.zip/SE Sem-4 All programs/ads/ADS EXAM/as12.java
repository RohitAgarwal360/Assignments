/*Any application defining scope of Formal parameter, Global parameter, Local parameter
 *Accessing mechanism and also relevance to private, public and protected access.
 * Write a Java program which demonstrates the scope rules of the programming mechanism.*/
/*
Author : codyapa
         
	 Akshay (AG)
         Vivek  (VG)
	 Ameya  (AD)
	 Akash  (AN)
	 Sourabh(SG)

*/

//import java.util.Scanner;
import java.lang.*;
class Person 
{
	
	protected int LicId;
	public String Name;
	public String Address;
	public static int count=0;
    Person(int L, String N, String A) 
    {
     	LicId=L;
     	Name=N;
     	Address=A;
    }
 }
class Employee extends Person
{
	private int  Emp_ID;
	private int Salary;
	private float tax;
	Employee(int L, String N, String A, int E, int S)
	{
		super(L,N,A);
		Emp_ID=E;
		Salary=S;
		count++;
	}
	
	void calc_tax(){tax=(float) (0.2*Salary);}
	void Displaydata()
	{//count++;
	calc_tax();
	System.out.println( LicId + "\t"+ Name + "\t"+ Address+ "\t"+ Emp_ID + "\t"+ Salary + "\t"+ tax);
	
        }

	void displayCount(){System.out.println("No. of Employee "+count);}
}
  class as12{

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	    {
		// TODO Auto-generated method stub 
		
		System.out.println( "LicId\tName\tAddress\tEmp_ID\tSalary\ttax");
		Employee emp1=new Employee(1,"ABC","Pune",1,21000);
		emp1.Displaydata();
		
		Employee emp2=new Employee(2,"DEF","Pune",10,2020);
		emp2.Displaydata();
		emp2.displayCount();
	}
}

/*

akash@Akash-HP:~$ cd Desktop/
akash@Akash-HP:~/Desktop$ javac Person_Info.java 
akash@Akash-HP:~/Desktop$ java Person_Info 
LicId	Name	Address	Emp_ID	Salary	tax
1	ABC	Pune	1	21000	4200.0
2	DEF	Pune	10	2020	404.0
No. of Employee 2
akash@Akash-HP:~/Desktop$ ^C
akash@Akash-HP:~/Desktop$ 


*/
