#include <iostream>
using namespace std;

class BstNode {
	int data;
	BstNode *rchild, *lchild;
	friend class BstTree;
	friend class stack;

public:
	BstNode() {
		data = 0;
		rchild = lchild = NULL;
	}
};

class stack {
	BstNode *item[50];
	int top;

public:
	stack() {
		top = -1;
	}

	BstNode* pop();
	int isEmpty();
	int isFull();
	void push(BstNode*data);
};

class BstTree {
	BstNode *root;
public:
	BstTree() {
		root = NULL;
	}

	BstNode* getNode();
	void createTree();
	void display_min();
	BstNode* getRoot();
	void search(BstNode*, int data);
	void display_tree(BstNode*);
	void mirror1();
	void mirror(BstNode* pt);
	void insert_node();
	int depth(BstNode* pt);
};

BstNode* stack::pop() {
	BstNode* data = NULL;
	if (isEmpty()) {
		cout << "\n Tree is empty";

	} else {
		data = item[top];
		top--;
	}
	return data;
}
int stack::isEmpty() {
	if (top == -1)
		return 1;
	else
		return 0;

}
int stack::isFull() {
	if (top == 50)
		return 1;
	else
		return 0;
}
void stack::push(BstNode*data) {
	if (isFull())
		cout << "\nStack is full";
	else {
		top++;
		item[top] = data;
	}
}

BstNode* BstTree::getNode() {
	BstNode* newnode = NULL;
	newnode = new BstNode;
	if (newnode == NULL)
		cout << "\nMemory allocation error";
	else {
		cout << "\n Enter data";
		cin >> newnode->data;
		newnode->lchild = NULL;
		newnode->rchild = NULL;
	}

	return (newnode);
}

void BstTree::createTree() {
	BstNode *p = new BstNode;
	cout << "\nEnter data:  ";
	cin >> p->data;

	if (root == NULL) {
		cout << "\n1st node inserted in BST...\n";
		root = p;
	} else {
		BstNode *temp, *cur;
		temp = root;
		cur = NULL;

		while (temp != NULL) {
			if (p->data < temp->data) {
				cur = temp;
				temp = temp->lchild;
			} else {
				cur = temp;
				temp = temp->rchild;
			}
		}

		if (p->data < cur->data) {
			cur->lchild = p;
		} else {
			cur->rchild = p;
		}
	}
}

void BstTree::display_min() // inorder sequence
{
	stack s;
	BstNode* pt = NULL;

	if (root == NULL) {
		cout << "\nTree is empty";
	} else {
		pt = root;

		while (pt != NULL) {
			s.push(pt);
			pt = pt->lchild;
		}

		if (!s.isEmpty()) {
			pt = s.pop();
			cout << "\nMinimum Value is: " << pt->data << endl;
		}
	}
}

BstNode* BstTree::getRoot() {
	return root;
}

void BstTree::search(BstNode* temp, int data) {
	if (temp) {
		if (temp->data == data) {
			cout << "\nData is found\n" << endl;
			return;
		} else {
			if (data < temp->data) {
				search(temp->lchild, data);
			} else {
				search(temp->rchild, data);
			}
		}
	} else
		cout << "\nData not found\n" << endl;
}

void BstTree::display_tree(BstNode* pt) {
	if (pt) {
		display_tree(pt->lchild);
		cout << pt->data << "\t";
		display_tree(pt->rchild);
	}
}

void BstTree::mirror1() {
	BstNode* pt = root;
	cout << " --- " << pt->data;
	mirror(root);
}
void BstTree::mirror(BstNode* pt) {
	BstNode *temp = NULL;
	if (pt != NULL) {
		mirror(pt->lchild);
		mirror(pt->rchild);
		temp = pt->lchild;
		pt->lchild = pt->rchild;
		pt->rchild = temp;
	}
}

int BstTree::depth(BstNode* pt) {
	int lt, rt;
	if (pt == NULL)
		return 0;
	else {
		lt = depth(pt->lchild);
		rt = depth(pt->rchild);

		if (lt < rt)
			return rt + 1;
		else
			return lt + 1;
	}

}

int main() {
	int a, count, search_val;
	BstTree d;
	string w, wordToDelete;
	do {
		cout
				<< "\n1)Insert a node\n2)Number of nodes in longest path\n3)Minimum data value in the tree\n4)Mirror Image of a tree\n5)Search a Value in a Tree\n6)Display\n7)Exit";
		cout << "\n Enter your choice:";
		cin >> a;
		switch (a) {
		case 1:
			d.createTree();
//			cout << "\nAfter Insertion of a node, Tree is as follows:";
//			d.display_tree();
			break;
		case 2:
			count = d.depth(d.getRoot());
			cout << "\nMaximum number of nodes along the longest path is "
					<< count;
			break;
		case 3:
			d.display_min();
			break;
		case 4:
			d.mirror1();
			d.display_tree(d.getRoot());
			break;
		case 5:
			cout << "\nEnter the data to be searched in the tree.";
			cin >> search_val;
			d.search(d.getRoot(), search_val); //non recursive
			break;
		case 6:
			d.display_tree(d.getRoot());
			break;
		case 7:
			break;
		default:
			cout << "\n Invalid Entry \n";
			break;
		}
	} while (a != 7);
}
