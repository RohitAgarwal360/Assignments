#include<iostream>
#include<cstring>
#define MAX 15
using namespace std;
class adm
{
    int mat[MAX][MAX],node;
    string c1[MAX],c2[MAX];
public:

    adm()
    {
        for(int i=0; i<MAX; i++)
            for(int j=0; j<MAX; j++)
                mat[i][j]=0;
    }

    void getnode()
    {
        cout<<"\nEnter no. of cities:\n";
        cin>>node;
        for(int i=0; i<node; i++)
        {
            cout<<"\nEnter name of city "<<i+1<<"\n";
            cin>>c1[i];
            c2[i]=c1[i];
        }
    }

    void getmat()
    {
        for(int i=1; i<node; i++)
            for(int j=0; j<i; j++)
            {
                cout<<"\nEnter Distance between "<<c1[i]<<" and "<<c2[j]<<"\n";
                cin>>mat[i][j];
                mat[j][i]=mat[i][j];
            }

    }

    void dismat()
    {   cout<<"\nMatrix representation of GRAPH--\n";
        cout<<"\t";
        for(int i=0; i<node; i++)
        {
            cout<<c1[i]<<"\t";
        }
        cout<<"\n";
        for(int i=0; i<node; i++)
        {
            cout<<c1[i]<<"\t";
            for(int j=0; j<node; j++)
            {
                cout<<mat[i][j]<<"\t";
            }
            cout<<"\n";
        }

    }
};

int main()
{
    adm obj;
    obj.getnode();
    obj.getmat();
    obj.dismat();
    return 0;

}
