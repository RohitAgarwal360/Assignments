#include<iostream>
#include<cstring>
#define MAX 15
using namespace std;
struct node
{char data;
node *next;
};

class adm
{
    int mat[MAX][MAX],node,edge=0;
    string c1[MAX],c2[MAX];
public:

    adm()
    {
        for(int i=0; i<MAX; i++)
            for(int j=0; j<MAX; j++)
                mat[i][j]=0;
    }

    void getnode()
    {
        cout<<"\nEnter no. of Vertices in graph:\n";
        cin>>node;
        for(int i=0; i<node; i++)
        {
            cout<<"\nEnter name of vertices "<<i+1<<"\n";
            cin>>c1[i];
            c2[i]=c1[i];
        }
    }

    void getmat()
    {
        for(int i=1; i<node; i++)
            for(int j=0; j<i; j++)
            {
                cout<<"\nEnter 1 if there is edge between "<<c1[j]<<" and "<<c2[i]<<" else 0 if not connected\n";
                cin>>mat[i][j];
                mat[j][i]=mat[i][j];
                if(mat[i][j]==1)
                 edge=edge+1;
            }

    }

    void dismat()
    {
        cout<<"\nMatrix representation of GRAPH--\n";
        cout<<"\t";
        for(int i=0; i<node; i++)
        {
            cout<<c1[i]<<"\t";
        }
        cout<<"\n";
        for(int i=0; i<node; i++)
        {
            cout<<c1[i]<<"\t";
            for(int j=0; j<node; j++)
            {
                cout<<mat[i][j]<<"\t";
            }
            cout<<"\n";
        }

        cout<<"\n Total No. of edges in graph="<<edge;
    }
};

int main()
{
    adm obj;
    obj.getnode();
    obj.getmat();
    obj.dismat();
    return 0;

}

