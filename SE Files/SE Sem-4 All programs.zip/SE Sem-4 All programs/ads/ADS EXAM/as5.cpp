
#include<iostream>
using namespace std;
#define MAX 26

class mob
{
 public:
 long int mobno,a[MAX]; int index,s;
 string name,b[MAX];
 public:
 void getdata();
 void display();
 void search();
};

void mob::getdata()
{
 for(int i=0;i<MAX;i++)
 {
  b[i]="0";
  a[i]=0;
 }
 int ch;
 do
 {
 cout<<"\nEnter the name :";
 cin>>name;
 cout<<"\nEnter the mobile number :";
 cin>>mobno;

 s=name[0];
 index=s-97;
 if(b[index]=="0")
 {
 a[index]=mobno;
 b[index]=name;
 }
 else
 {
 while(b[index]!="0")
 {
 index++;
 }
 a[index]=mobno;
 b[index]=name;
 }
 cout<<"\nDo you want to enter another number(1/0) :";
 cin>>ch;
 }while(ch==1);
}

void mob::search()
{
 cout<<"\nEnter name to be searched :";
 cin>>name;
 s=name[0];
 index=s-97;
 if(a[index]!=0)
 {
  cout<<"\nNumber found \n"<<"Name :"<<b[index]<<"\nNumber :"<<a[index];
 }
 else
 {
  cout<<"\n!!! NOT FOUND !!!";
 }
}

void mob::display()
{
 cout<<"\n\n\tNAME\tMobile Number\n";
 cout<<"\t----\t-------------\n";
 for(int i=0;i<MAX;i++)
 {
 cout<<"\t"<<b[i]<<"\t"<<a[i];
 cout<<"\n";
 }
}

int main()
{
 int m,o;
 mob obj;
 do
 {
 cout<<"\n\n*****MENU*****\n";
 cout<<"\n1.CREATE \n2.DISPLAY \n3.SEARCH ";
 cout<<"\nEnter choice :";
 cin>>o;
 switch(o)
 {
 case 1:obj.getdata();
        break;
 case 2:obj.display();
        break;
 case 3:obj.search();
      break;
 }
 cout<<"\nDo you want to continue(1/0) :";
 cin>>m;
 }while(m==1);
 return 0;
}
