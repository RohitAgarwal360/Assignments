
// set operations using STL
#include<iostream>
#include<set>
#include<algorithm>
#include<vector>
using namespace std;
int main()
{
	char y='y';
	int s1,s2;
	int a[20];
	int b[20];
	        cout<<"\n\tcodyapa\n\n";
		cout<<"*** PROGRAM OF OPERATIONS ON SET ***";
		cout<<"\n Adding elements:";
		cout<<"\nEnter size of Set I and Set II :"<<endl;
		cin>>s1>>s2;
		cout<<"Enter elements of Set I :"<<endl;
	for(int i=0; i<s1; i++){
		cin>>a[i];
	}
		cout<<"\nEnter elements of Set II :"<<endl;
	for(int i=0; i<s2; i++){
			cin>>b[i];
	}
		set<int> I(a,a+s1);
		set<int> II(b,b+s2);
		vector<int> v(s1+s2);
		vector<int>::iterator i;
		set<int>::iterator it;
int ch;
int x=0;
int ch2;
int key;
do{
	cout<<"\n Menu:";
	cout<<"\n 1.Remove";
	cout<<"\n 2.Display";
	cout<<"\n 3.Union of sets";
	cout<<"\n 4.Intersection of sets";
	cout<<"\n 5.Difference of sets";
	cout<<"\n Enter your choice:";
	cin>>ch;
	switch(ch){
	case 1:
			cout<<"Remove from Set I or Set II?";
			cin>>ch2;
			cout<<"Enter the element to be deleted:";
			cin>>key;
			switch(ch2){
			case 1:
				for(it=I.begin();it!=I.end();it++){
					if(*it==key){
						break;
					}
				}
					I.erase(it);
			break;
			case 2:
				for(it=II.begin();it!=II.end();it++){
					if(*it==key){
						break;
					}
				}
					II.erase(it);
			break;
			}
			x++;
			v.resize(s1+s2-x);
			break;
	case 2:
			cout<<"\n Size of set I: "<<I.size();
			cout<<"\n Elements are:";
			for(it=I.begin();it!=I.end();it++)
				cout<<" "<<*it;
			cout<<"\n Size of set II: "<<II.size();
			cout<<"\n Elements are:";
			for(it=II.begin();it!=II.end();it++)
				cout<<" "<<*it;
			break;
	case 3:
			i=set_union(a,a+s1,b,b+s2,v.begin());
			v.resize(i-v.begin());
			cout<<"\nUNION: ";
			for(i=v.begin();i!=v.end();i++)
				cout<<" "<<*i;
			break;
	case 4:
			i=set_intersection(a,a+s1,b,b+s2,v.begin());
			v.resize(i-v.begin());
			cout<<"\n INTERSECTION: ";
			for(i=v.begin();i!=v.end();i++)
				cout<<" "<<*i;
			break;
	case 5:
			i=set_difference(a,a+s1,b,b+s2,v.begin());
			v.resize(i-v.begin());
			cout<<"\n SET DIFFERENCE: ";
			for(i=v.begin();i!=v.end();i++)
				cout<<" "<<*i;
			break;
	}
		cout<<"\n Do you want to continue?(y,n) : ";
			cin>>y;
}while((y=='y')||(y=='Y'));
return 0;
}


/*OUTPUT
vivek@vivek-gouda-pc:~/Desktop$ clear

vivek@vivek-gouda-pc:~/Desktop$ ./a.out

	codyapa

*** PROGRAM OF OPERATIONS ON SET ***
 Adding elements:
Enter size of Set I and Set II :
3
4
Enter elements of Set I :
1
2
3

Enter elements of Set II :
2
3
4
5

 Menu:
 1.Remove
 2.Display
 3.Union of sets
 4.Intersection of sets
 5.Difference of sets
 Enter your choice:2

 Size of set I: 3
 Elements are: 1 2 3
 Size of set II: 4
 Elements are: 2 3 4 5
 Do you want to continue?(y,n) : y

 Menu:
 1.Remove
 2.Display
 3.Union of sets
 4.Intersection of sets
 5.Difference of sets
 Enter your choice:3

UNION:  1 2 3 4 5
 Do you want to continue?(y,n) : y

 Menu:
 1.Remove
 2.Display
 3.Union of sets
 4.Intersection of sets
 5.Difference of sets
 Enter your choice:4

 INTERSECTION:  2 3
 Do you want to continue?(y,n) : y

 Menu:
 1.Remove
 2.Display
 3.Union of sets
 4.Intersection of sets
 5.Difference of sets
 Enter your choice:5

 SET DIFFERENCE:  1
 Do you want to continue?(y,n) : y

 Menu:
 1.Remove
 2.Display
 3.Union of sets
 4.Intersection of sets
 5.Difference of sets
 Enter your choice:2

 Size of set I: 3
 Elements are: 1 2 3
 Size of set II: 4
 Elements are: 2 3 4 5
 Do you want to continue?(y,n) : y

 Menu:
 1.Remove
 2.Display
 3.Union of sets
 4.Intersection of sets
 5.Difference of sets
 Enter your choice:1
Remove from Set I or Set II?1
Enter the element to be deleted:1

 Do you want to continue?(y,n) : y

 Menu:
 1.Remove
 2.Display
 3.Union of sets
 4.Intersection of sets
 5.Difference of sets
 Enter your choice:2

 Size of set I: 2
 Elements are: 2 3
 Size of set II: 4
 Elements are: 2 3 4 5
 Do you want to continue?(y,n) : ^C  
vivek@vivek-gouda-pc:~/Desktop$ 


*/
