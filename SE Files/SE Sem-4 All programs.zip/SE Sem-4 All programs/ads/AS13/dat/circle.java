package dat;
//import dat.inter;
import java.util.Scanner;
public class circle implements inter
{
  public float area()
  {
     System.out.println("Enter the Radius of a circle");
     Scanner sc=new Scanner(System.in);
     float r=sc.nextFloat();
     return (pi*r*r);
   }
 }
