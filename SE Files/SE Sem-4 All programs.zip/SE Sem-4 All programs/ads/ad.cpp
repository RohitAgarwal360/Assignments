#include<iostream>
#include<iomanip>
using namespace std;
#define MAX 10

int main()
{
  int g[MAX][MAX],i,j,n,e,u,v,w;
   cout<<"\n Enter number of vertices:";
   cin>>n;
   for(i=0;i<=n;i++)
   {
    for(j=0;j<=n;j++)
    {
      g[i][j]=0;
    }
   }
 
   cout<<"\n Enter number of edeges:";
   cin>>e;
   for(i=1;i<=e;i++)	
   {
     cout<<"\n Enter edege in the form of(u,v,w):";
     cin>>u>>v>>w;
     g[u][v]=w;
     g[v][u]=w;
   
   }
   
   cout<<"\n Graph entered by user:"<<endl;
  cout<<setw (14)<<"c0";
  //<<setw (7)<<"c1"<<setw(7)<<"c2"<<setw(7)<<"c3";
    for(i=1;i<=n;i++)
    cout<<setw (7)<<"c"<<i;
   
   for(i=0;i<=n;i++)
   {
     cout<<"\n"<<setw(7)<<"r"<<i;
     for(j=0;j<=n;j++)
     {
      cout<<setw(7)<<g[i][j];
     }
   }
   cout<<endl;
return 0;
}
