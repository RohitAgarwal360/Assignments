#include<iostream>
#define MAX 50
using namespace std;

struct node
{
  int nei,weight;
  struct node *next;
};


void print(struct node *g[MAX],int n)
{
  struct node *p;
  for(int i=1;i<=n;i++) //n
  {
  	 p=g[i];
  	 while(p!=NULL)
  	 {   //if(i!=p->nei) 
  	 	cout<<i<<" neighbour:  "<<p->nei<<"  Weight:  "<<p->weight<<endl;
  	 	p=p->next;
  	      // }	
  	 }      
   cout<<endl;
  }
cout<<endl;

}




int main()
{
  struct node *g[MAX],*p1,*p2;
  int i,n,e,u,v,w;
  cout<<"\n Enter number of vertices:";
  cin>>n;
  for(i=1;i<=n;i++)
  {
    g[i]=NULL;
  } 
  
  cout<<"\n Enter number of edeges:";
  cin>>e;
  for(i=1;i<=e;i++) //i=1   i<=e
  {
  	cout<<"\n Enter edge in the form of(u,v,w):";
  	cin>>u>>v>>w;
  	p1=new node;
  	p1->nei=v;
  	p1->weight=w;
  	p1->next=NULL;
  	
  	if(g[u]==NULL)
  	 {
  	 	g[u]=p1;
  	 }
  	
  	else
  	{
  	 	p2=g[u];
  	 	 while(p2->next!=NULL)
  	 	 {
  	 	  p2=p2->next;
  	 	 }
  	        p2->next=p1;
  	}
  	
  	p1=new node;
  	p1->nei=u;
  	p1->weight=w;
  	p1->next=NULL;
  	
  	if(g[v]==NULL)
  	 {
  	 	g[v]=p1;
  	 }
  	
  	else
  	{
  	 	p2=g[v];   //v
  	 	 while(p2->next!=NULL)
  	 	 {
  	 	  p2=p2->next;
  	 	 }
  		 p2->next=p1; 
  	}
  		
  	
  }

	print(g,n);
return 0;
}
