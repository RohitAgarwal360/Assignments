import java.util.*;

class c
{
 private int a=20;
 public int b=30;
 protected int c=40;
 public static int x=100; //global parameter 
 void add(int a, int b)  //formal paramter
  {
   System.out.println(a+b);
   } 
}

public class app extends c
 {   
  /* private int a=10;
   public int b=5;
   protected int c=0;
*/   
   
  public static void main(String [] args)
   {int z=10;
      app obj= new app(); 
      
     System.out.println(obj.b+"\n" +obj.c );
     //System.out.println(" "+obj.a);
     obj.add(obj.b,obj.c);  //actual paramter
     
     System.out.println("local variable in main is= "+z);
     System.out.println("Global variable is x ="+x );
    } 
    
    
 } 
     
   

