# include <iostream>
# include <cstdlib>
# include <string.h>
using namespace std;

struct node
{
	char name[20];
	int n;
	node *next[10];
};

class tree
{
	public:
	node *root,*p,*q,*r;
	
	tree()
	{
		root=NULL;
	}

	void create();
	void chapter(struct node *);
	void section(struct node *);
	//void subsection(struct node *);
	void display();
};

void tree::create()
{
	int i;
	cout<<"\nEnter Book Name:- ";
	root=new node;
	cin>>root->name;
	cout<<"\nEnter no. of Chapters:- ";
	cin>>root->n;

	for(i=0;i<root->n;i++)
	{
		cout<<"\nEnter Chapter Name:- ";
		root->next[i]=new node;
		p=root->next[i];
		chapter(p);
		//root->next[i+1]=NULL;
	}

}

void tree::chapter(struct node *p)
{
	int i;
	cin>>p->name;
	cout<<"\nEnter no. of Sections:- ";
	cin>>p->n;
	//q=p;

	for( i=0;i<p->n;i++)
	{
		cout<<"\nEnter Section Name:- ";
		p->next[i]=new node;
		q=p->next[i];
		cin>>q->name;
		section(q);
		//p->next[i+1]=NULL;
	}
}

void tree::section(struct node *p)
{	
	int i;
	cout<<"\nEnter no. of Sub-Sections:- ";
	cin>>p->n;
	//q=p;

	for( i=0;i<p->n;i++)
	{
		cout<<"\nEnter Sub-Section Name:- ";
		p->next[i]=new node;
		q=p->next[i];
		cin>>q->name;
		//p->next[i+1]=NULL;
	}
}


void tree::display()
{
	//node *p,*q,*k
	//int i,j,k;
	cout<<"\nBook name:- "<<root->name;

	for(int i=0;i<root->n;i++)
	{
		p=root->next[i];
		cout<<"\nChapter name:- "<<p->name;
		
		for(int j=0;j<p->n;j++)
		{
			q=p->next[j];
			cout<<"\nSection name:- "<<q->name;
			
			for(int k=0;k<q->n;k++)
			{
				r=q->next[k];
				cout<<"\nSub-Section name:- "<<r->name;
			}
		}
	}
}
int main()
{
	tree t;
	t.create();
	t.display();
	cout<<"\n";
	return 0;
}
