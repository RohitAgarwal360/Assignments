#include<iostream>
#include<iomanip>
using namespace std;
class flight
{
	int graph[10][10],n,i;
	char name[10][10];  //[10][10]

	public:  flight()
	          {  for(int p=0;p<10;p++)
	               for(int q=0;q<10;q++)
	                  graph[p][q]=0;
	           } 
                void getdata();
		void putdata();
};
void flight::getdata()
{
	cout<<"\nEnter No. Of Cities:- ";
	cin>>n;
	for(i=0;i<n;i++)
	{
		cout<<"\nEnter Name Of "<<i+1<<" Cities:- ";
		cin>>name[i];
	}
	cout<<"\nEnter travel detail:- (Enter zero if no path between two cities)";
	for(i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{    if(j>i)
		     {
		  cout<<"\nEnter Fuel required from  "<<name[i]<<"  to  "<<name[j]<<"  :- \n";
			cin>>graph[i][j];
			graph[j][i]=graph[i][j];
		      }
		}
		//cout<<endl;
	}	
}

void flight::putdata()
{
	cout<<"\nFlight Representation :-\n";
	cout<<setw(14)<<name[0];
          for(i=0;i<n-1;i++)
	   cout<<setw(7)<<name[i+1];	
	
	cout<<endl;
	for(i=0;i<n;i++)
	{   
	   cout<<setw (7)<<name[i];	
		for(int j=0;j<n;j++)
		{
			cout<<setw(7)<<graph[i][j];
		}
	 cout<<"\n";	
	}
		
}


int main()
{
        cout<<"Welcome to airways please enter the below data first";
	flight f;
	f.getdata();
	f.putdata();
	cout<<"\nHappy Journey!!!!!\n";

	return 0;
}
