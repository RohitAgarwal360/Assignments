#include<iostream>
#include<fstream>
#include<cstring>
#include<cstdio>
#include<iomanip>
#include<cstdlib>
using namespace std;
class student 
{
        public:
        char name[20];
        int rollNo;
        char div;
        char address[100];
        public:void getdata();
               void putdata();
};
void student::getdata()
{
    cout<<"\nEnter student name :";
    
    cin>>name;
    cout<<"Enter roll no :";
    cin>>rollNo;
    cout<<"Enter div :";
    cin>>div;
    cout<<"Enter address ";
    cin.ignore();
    cin.getline(address,100);

}
void student::putdata()
{
    cout<<"\nStudent name is :"<<name;
    cout<<"\nRoll no :"<<rollNo;
    cout<<"\nDivision is :"<<div;
    cout<<"\nAddress is :"<<address<<endl;
}
int main()
{
      
        student obj;
        int n,roll;
        fstream file;
        //Create file 
        file.open("student.dat",ios::app|ios::binary);
        file.close();
        file.open("student.dat",ios::in|ios::out|ios::binary|ios::ate);
        
        //Input from user and store in file
        cout<<"Enter number of records ";
        cin>>n;
        for(int i=0;i<n;i++)
        {
                 obj.getdata();
                 file.seekp(0,ios::end);
                 file.write((char *)&obj,sizeof(student));
        }
        
       //Read data from file and print
       file.seekp(0,ios::beg);
        while(file.read((char *)&obj,sizeof(student)))
        {
            obj.putdata();
        }
        

        //Search and Delete record 
        fstream temp;
        temp.open("temp.dat",ios::out|ios::app|ios::binary);
        temp.close();
        temp.open("temp.dat",ios::in|ios::out|ios::binary|ios::ate);
        cout<<"Enter roll no whose record is to be deleted :";
        cin>>roll;
        file.clear();
         file.seekg(0,ios::beg);
         
          while(file.read((char *)&obj,sizeof(student)))
        {
          
            
            if(obj.rollNo==roll)
             continue;

             temp.write((char *)&obj,sizeof(student));
                    
        } 
           
           temp.close();
           file.close();
           remove("student.dat");
           rename("temp.dat","student.dat");


            //Read data from file and print
          file.open("student.dat",ios::in|ios::out|ios::binary|ios::ate);
            file.seekp(0,ios::beg);
        while(file.read((char *)&obj,sizeof(student)))
        {
            obj.putdata();
        }
        file.close();

        return 0;

}
