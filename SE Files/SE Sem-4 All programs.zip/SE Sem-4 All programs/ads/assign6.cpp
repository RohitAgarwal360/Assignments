#include<iostream>
#include<string.h>
#define MAX 26
using namespace std;


struct dict
{
	char w[20];
	char m[20];
}d[MAX];


class dictionary
{
	
	public:
		dictionary()
		{
			for(int i=0;i<MAX;i++)
			{
				d[i].w[0]='\0';
				d[i].m[0]='\0';
			}
		
		
		}

	void display();
	int hash(char w[20]);
	void create();
	void erase(int f,int key);
	int search(char w[20],int key);

};

int dictionary::hash(char w[20])
{
	if(w[0]>='A' && w[0]<='Z')
		return (w[0]-65);			
	else if(w[0]>='a' && w[0]<='z') //A=65 TO Z=90
		return (w[0]-97);      //a=97 to z=122
}



void dictionary::create()
{
    	dict temp;
	cout<<"\n Enter word to insert:";
	cin>>temp.w;
	cout<<"\n Enter meaning of word:";
	cin>>temp.m;
    	int key=hash(temp.w);
	
	int flag=0,cnt=0,i;
	
	if(d[key].w[0]=='\0')
	{
		
		strcpy(d[key].w,temp.w);
		strcpy(d[key].m,temp.m);
		
	}

	else
	{
		i=0;
		while(i<MAX)	
		{
			if(d[i].w[0]!='\0')
				cnt++;
		
			i++;	
		}
		
		if(cnt==MAX)
		{
			cout<<"\n Dictionary is full!!....can't insert.";
		}
		
		else
		{
			for(i=key+1;i<=MAX;i++)
			{
			     i=i%26;	
				if(d[i].w[0]=='\0')
			         {
				        
				        strcpy(d[i].w,temp.w);
					strcpy(d[i].m,temp.m);
				 	//flag=1;
				 	break;
				 }
			
			}
			
			/*for(i=0;i<key && flag==0;i++)
			{
				if(d[i].w[0]=='\0')
			         {
				        strcpy(d[i].w,temp.w);
					strcpy(d[i].m,temp.m);
				 	flag=1;
				 	break;
				 }
			
			}*/
			
		
		
		}
	
	}


}


void dictionary::display()
{
	cout<<"\n.....................DICTIONARY............";
	cout<<"\n\n\tKey\tWORD\tMEANING";
	for(int i=0;i<MAX;i++)
	{
		cout<<"\n\t"<<i<<"\t"<<d[i].w<<"\t"<<d[i].m;
	}

}





int dictionary::search(char w[20],int key)
{
	
	while(d[key].w!='\0')
	{
		if(strcmp(d[key].w,w)==0)
		{
			return key;
		}
	      key++;
            //   if(key>=25)		 
		key=key%MAX;
	}

return -1;
}


void dictionary::erase(int f,int key)
{
			
	if(f!=-1)
	{
	  d[key].w[0]=d[key].m[0]='\0';
	  cout<<"\n Word Deleted Successfully!!";
	} 
		
	else
	 cout<<"\n Word NOT found to delete!!";	
	}



int main()
{
dictionary obj;
int c;
	while(1)
	{
		cout<<"\n\n.................MENU....................";
		cout<<"\n 1.Insert \n 2.Display \n 3.Search \n 4.Delete \n 5.Exit";
		cout<<"\n Enter your choice:";
		cin>>c;
		
		switch(c)
		{
			case 1:
			{	obj.create();
				break;
			}

			case 2:
			{
				
				obj.display();
				break;
			}
		
			case 3:
			{
				char w[20];
				cout<<"\n Enter word to search:";
				cin>>w;
				int key=obj.hash(w);
				int f=obj.search(w,key);
				if(f!=-1)
				{
				 	cout<<"\n Word found Successfully!!";
                 cout<<"\n Key:"<<f<<"\tWord:"<<d[f].w<<"\t Meaning:"<<d[f].m;
				}
				else
					cout<<"\n Word NOT found!!";
				
				
				break;
			}	

			case 4:
			{	
				char w[20];
				cout<<"\n Enter word to delete:";
				cin>>w;
				int key=obj.hash(w);
				int f=obj.search(w,key);			
				
				obj.erase(f,key);				
				
										
				break;
			}		

			case 5:
			{
				return 0;
			
			}
					
		
		
		
		
		}
	
	}





}


















