#include<iostream>
using namespace std;
 static int cnt;
 //static int min;
 static bool flag=true;
 static bool fl=true;
struct node
{
 int data;
 struct node *left,*right;
 };
 
 struct node * insert(struct node *t,int x)
 {
   struct node *p,*q,*r;
   int i,j;
   r=new node;
   r->data=x;
   r->left=NULL;
   r->right=NULL;
   if(t==NULL)
    return r;
   p=t;
   while(p!=NULL)
    {
     q=p;
     if(p->data>x)
      p=p->left;
     else
      p=p->right;
    }
    if(q->data>x)
        q->left=r;
    else
        q->right=r;
   return t;
   }
 
 void preorder(struct node *t)
{
 if(t!=NULL)
  {
   cout<<" "<<t->data;
   preorder(t->left);
   preorder(t->right);
  // cout<<" "<<t->data;
  }

}


void inorder(struct node *t)
{
 if(t!=NULL)
  {
   
   inorder(t->left);
   cout<<" "<<t->data;
   inorder(t->right);
  }
 }
 
//for mirroring
void nodechng(node *R)
{
	static node *p;
	if(R!=NULL)
	{
		p=R->right;
		R->right=R->left;
		R->left=p;
		nodechng(R->left);
		nodechng(R->right);
	}

} 
 
 
  
/*void lng(struct node *t) //for counting the leaf nodes
  { //static int cnt;
    if(t!=NULL)
    {
     if(t->left==NULL && t->right==NULL)
     { 
     cnt=cnt+1;
     }
    lng(t->left);
    lng(t->right);
    }
 }*/
 
int lo(struct node *R)
 {
 int lt, rt;
	if (R == NULL)
		return 0;
	else {
		lt = lo(R->left);
		rt = lo(R->right);

		if (lt < rt)
			return rt + 1;
		else
			return lt + 1;
 
              } 
 }
 
 
 
 
 
 
void min1(struct node *t)
  { 
     //min=t->data;
    if(t!=NULL)
     { 
       if(flag==true)
         {
          cnt=t->data;
         flag=false;
          }
       if(t->data<=cnt && flag==false)
         {
          cnt=t->data;
         }
      min1(t->left);
      min1(t->right);
     }
   }  
void search(struct node *t,int b)   
   { 
      if(t!=NULL)
       { 
         if(t->data==b)
          fl=false;
         search(t->left,b);
         search(t->right,b); 
       } 
     
   }
int main()
  {
   int a,x,b;
   struct node *root;
   root=NULL;
   cout<<"Enter the number of nodes"<<endl;
   cin>>a; 
     for(int i=0;i<a;i++)
       {
        cout<<"Enter the data in binary tree : ";
        cin>>x;
        root=insert(root,x);
       }
    cout<<"\nin preorder \n";
    preorder(root);    
    cout<<"\n\nYour binary tree is (inorder) :\n";
    inorder(root);
   
    cout<<"\n";
   /* lng(root);
    cout<<"\nno of leafs in tree is= "<<cnt<<endl;*/
  
    min1(root);
    cout<<"min value in the node is= "<<cnt<<endl;
    
        
    cout<<"Enter the data in node that you want to search ";
    cin>>b;
    search(root,b);
    if(fl==false)
     cout<<"data "<<b<<"is present"<<endl;
    else
     cout<<"not present"<<endl;
    
    
    
    int k;
    k=lo(root);
    cout<<"longest path= "<<k<<endl;  
     
    nodechng(root);
	cout<<"\n\nNODES ARE INTERCHANGED IN ENTERED BINARY TREE:\n"; 
    cout<<"\nin preorder \n";
    preorder(root);    
    cout<<"\n\nYour binary tree is (inorder) :\n";
    inorder(root);	
     
    return 0;
   }             
                
                
                
                
                
                
                
                
                
                
                
                
