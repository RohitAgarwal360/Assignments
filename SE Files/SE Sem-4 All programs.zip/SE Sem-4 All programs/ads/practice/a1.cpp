#include<iostream>
#include<cstring>
#include<stdlib.h>
using namespace std;
struct node{
 char name[20];
 int n;
 node *next[10];
  };
  
 class book{
    public:
    struct node *root,*p,*q,*r;
    book()
     {
      root=NULL;
     }
     
   void create();
   void chapter(struct node *);
   void section(struct node *);
   void display();
 };
 void book::create()
 {
    cout<<"Enter the book name: ";
    root=new node;
    cin>>root->name;
    cout<<"Enter the number of chapters: ";
    cin>>root->n;
    for(int i=0;i<root->n;i++)
     {
       cout<<"Enter the name of chapter: ";
        root->next[i]=new node;
        p=root->next[i];
        cin>>p->name;
        chapter(p);
      }
  }
 void book::chapter(struct node *p)
 { 
     cout<<"Enter the number of section: ";
     cin>>p->n;
     for(int i=0;i<p->n;i++)
     {
       cout<<"Enter the section name: ";
       p->next[i]=new node;
        q=p->next[i];
       cin>>q->name;
        section(q);
       }
   }
 void book::section(struct node *p)
     {
        cout<<"Enter number of subsections: ";
        cin>>p->n;
        for(int i=0;i<p->n;i++)
        {
          cout<<"Enter the subsection name: ";
          p->next[i]=new node;
           q=p->next[i];
          cin>>q->name;
          }
      }
 void book::display()
   { cout<<"\n\n=========================o/p==================================="<<endl;
       cout<<"book name: "<<root->name<<endl;
        for(int i=0;i<root->n;i++)
         {     p=root->next[i];
           cout<<"chapter name: "<<p->name<<endl;
              for(int j=0;j<p->n;j++)
                {  q=p->next[j];
                   cout<<"Section name: "<<q->name<<endl;
                   for(int k=0;k<q->n;k++)
                     {   r=q->next[k];
                         cout<<"subsection name: "<<r->name<<endl;
                      }
                  }
           }
    }
                          
  int main()
  {
     book b;
     b.create();
     b.display();
    return 0;
   }                           
                                     
       
                    
    
   
