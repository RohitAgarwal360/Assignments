package dat;
import java.util.*;

public class circle implements inter //()
 {
   
  public float area()
    {System.out.println("Enter the radius of circle");
   Scanner sc =new Scanner(System.in);
   float a=sc.nextFloat();
    
      return(pi*a*a);
     } 
   }
