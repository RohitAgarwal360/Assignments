package dat;
public interface inter
 {
  public float pi=3.14F;
   public float area();
  } 
