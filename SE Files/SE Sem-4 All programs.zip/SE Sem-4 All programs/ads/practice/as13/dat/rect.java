package dat;
import java.util.*;

public class rect implements inter
 { 
   
   public float area()
     { Scanner sc=new Scanner(System.in);
   System.out.println("Enter the length :");
    float l =sc.nextFloat();
    System.out.println("Enter the bredth: ");
    float b =sc.nextFloat();
    float ans= l*b;
       return(ans);
     }
  }   
      
