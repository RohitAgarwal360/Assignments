import dat.*;
public class m
  {
   public static void main(String args[])
    {
     circle obj1=new circle();
     float area1=obj1.area();
     
     rect obj2=new rect();
     float area2=obj2.area();
     
     System.out.println("Area of circle: "+area1);
     System.out.println("area of rectangle: "+area2);
     }
   }  
