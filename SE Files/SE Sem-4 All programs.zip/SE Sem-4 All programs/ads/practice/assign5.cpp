#include<iostream>
#include<stdlib.h>
 using namespace std;

    
int main()
  {
      int total;
      cout<<"Enter total no of client "<<endl;
      cin>>total;
      long int *ht = new long int [total];
      
      for(int i=0;i<total;i++)
        {
          ht[i]= -1 ;
        }
        
      long int b;
      long int c=0;
     
      for(int i=0; i<total; i++)
        {
           cout<<"Enter no. of client "<< i+1 <<endl;
           cin>>b;
           //cout<<"im in for ";  
           c=b%total;
           bool flag;
      
         
       do{
          
           flag=false;
          
           if(ht[c]==-1)
              { 
              flag=true;
              ht[c]=b; 
              }
          
           else
             {
              c++;
             }
        
       }while(flag==false); //continue till flag is false
         
    }
         
       cout<<"hash table :"<<endl;
       
       for(int i=0; i<total; i++)
         {
           cout<<ht[i]<<endl;
          } 
long int z=0;
long int y=0;          
cout<<"Enter the number you want to search in the hash table"<<endl;
cin>>z;     
    y=z%total;  
     bool flag;
int cnt=0;     
   //  bool a=true;
     do{    
         flag=false;
        if(z==ht[y])
         {
           flag=true;
           cout<<"key is present in the hash table\n";
           exit(0);
          }
         else
          {
          // if( ||a==true)            
              y++;
              cnt++; 
           }    
        }while(cnt<total);     
          
     cout<<"Sorry key is not present";     
          
 return 0;         
 }
