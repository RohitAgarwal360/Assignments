#include<iostream>
//Linear Probing without chaining
using namespace std;
struct client
{
       int custNo;
       long int tel;
};
 static const int Size=10;
      
class hashTable
{
       struct client table[Size];
       int mod=Size;
       public:hashTable()
              {
					    for(int i=0;i<10;i++)
				   {
						table[i].custNo=0;
						table[i].tel=0;
				    }
          }        
              void getdata();
              void display(int);
              
};
void hashTable::getdata()
{
       int no,n,hash;
       
       long int tel;
       bool flag;
       
        cout<<"Enter Customer Number :";
             cin>>no;
             cout<<"Enter Telephone number :";
             cin>>tel;
              hash=no%mod;
             if(table[hash].custNo==0)
             {
                    
                               table[hash].custNo=no;
                               table[hash].tel=tel;
                               
                   
             }
             else
             {
                                        
                     
             flag=false;
                    if(table[hash].custNo%mod==hash)
                    {
                          for(int j=(hash+1)%Size;j!=hash;j=(j+1)%Size)
                          {
                                 if(table[j].custNo == 0)
                                 {
                                        table[j].custNo=no;
                                        table[j].tel=tel;
                                        break;
                                        flag=true;
                                  }
                           }
                           if(flag==false)
                           {
                             
                             cout<<"Table is full"<<endl;
                            } 
                             
                    }
     
             }
       
        

}
void hashTable::display(int val)
{
                 int hash;
                 hash=val%mod;
                 bool flag;
                 if(table[hash].custNo==val )
                 {
                        cout<<"Customers telephone number is :"<<table[hash].tel<<endl;
                      
                 }
                  else
                  {
                          flag=false;
                          for(int j=(hash+1)%Size;j!=hash;j=(j+1)%Size)
                          {
                                 if(table[j].custNo == val)
                                 {
                                        
                                      cout<<"Customers telephone number is :"<<table[j].tel<<endl;
                 
                                        flag=true;
                                        break;
                                  }
                           }
                           if(flag==false)
                           {
                           cout<<"Customer number not found !"<<endl;
                           
                           }
                    }
}

int main()
{
        hashTable obj;
        int custNo,choice;
        
        while(1)
        {
           cout<<"\nHash Table\n1.Insert Data\n2.Search\n3.Exit\nEnter choice :";
           cin>>choice;
           
           switch(choice)
           {
               case 1:obj.getdata();
                      break;
               case 2:cout<<"Enter customer number :";
                      cin>>custNo;
                      obj.display(custNo);
                      break;
               case 3:return 0;       
               
               default:cout<<"Invalid Choice !";
                       break;
            }         
        
        }
        return 0;
}           
                         
                        
              
