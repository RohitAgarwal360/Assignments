#include<iostream>
using namespace std;

struct node
{
	int data;
	node *right ,*left;
	
};

node * insert (node *T,int x)
{
	node *r,*p;
	int i,j;
	r=new node;
	r->data=x;
	r->left=r->left=NULL;
	
	if(T==NULL)
	{
		return r;
	}
	p=T;
	while(p!=NULL)
	{
		if(p->data<x)
		{
			if(p->right==NULL)
				break;
			p=p->right;
		}
		else
		{
			if(p->left==NULL)
				break;
			p=p->left;
		}	
	}
	if(p->data>x)
			p->left=r;
		else
			p->right=r;
	return T;
}



void display(node *R)
{
	
	if(R!=NULL)
	{
		display(R->left);
		cout<<R->data<<"\t";
		display(R->right);
	}

}

int min(node *R)
{
	static int x=R->data;
	if(R!=NULL)
	{
		min(R->left);
		if(x>(R->data))
		{
			x=R->data;
		}
		min(R->right);
	}
return x;
}

int search(node *R,int key)
{
	static int flag=0;
	static int x=key;
	if(R!=NULL)
	{
		search(R->left,x);
		if(x==(R->data))
		{
			flag=1;
		}
		search(R->right,x);
	}
	if(flag==1)
	return 1;
	
	return -1;
}

int lng(node *R)
{
	static int i,max;
	if(R!=NULL)
	{
		if(max<i)
		max=i;
		i++;
		lng(R->left);
		lng(R->right);
		i--;
	}
	return max;
}
void nodechng(node *R)
{
	static node *p;
	if(R!=NULL)
	{
		p=R->right;
		R->right=R->left;
		R->left=p;
		nodechng(R->left);
		nodechng(R->right);
	}

}
int main()
{
	node *root;
	root=NULL;
	int i,n,x;
	cout<<"\n\n#ENTER NUMBER OF VALUES U WANT TO ENTER IN BINARY SERACH TREE..?\n";
	cin>>n;
	for(i=0;i<n;i++)
	{
		cout<<"\n\n#ENTER VALUE TO BE INSERTED:\t";
		cin>>x;
		root=insert(root,x);
	}
	cout<<"\n\n#THIS IS THE ENTERED BINARY TREE IN INORDER FORMAT:-\n";
	display(root);
	x=min(root);
	cout<<"\n\n#MIN NUMBER IN ENTERED BINARY TREE:\t";
	cout<<x;
	cout<<"\n\n#ENTER VALUE U WANT TO SEARCH IN BINARY TREE:\n";
	cin>>x;
	i=search(root,x);
	if(i==1)
	cout<<"\nKEY FOUND....!!!!";
	else
	cout<<"\nKEY NOT FOUND";
	cout<<"\n\n#LONGEST PATH IN ENTERED BINARY TREE IS:\t";
	i=lng(root);
	cout<<i;
	nodechng(root);
	cout<<"\n\n#NODES ARE INTERCHANGED IN ENTERED BINARY TREE:\n";
	display(root);
	cout<<"\n";
	return 0;
}
