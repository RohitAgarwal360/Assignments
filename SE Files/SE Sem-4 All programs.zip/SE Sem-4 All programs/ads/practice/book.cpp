#include<iostream>
#include<string.h>
using namespace std;
#define MAX 20
struct node
{
 char data[MAX];
 struct node *left,*right;
};

struct node * create()
{
 char c[MAX];
 char c1[]={"n"};
 struct node *p;
 cout<<"\n Enter DATA or enter 'n'  if no data :";
 cin.getline(c,20);
 if(!strcmp(c,c1))
  return NULL;
 p=new node;
 strcpy(p->data,c);
 cout<<"\n Enter data for left :"<<c;
 p->left=create();
 cout<<"\n Enter data for right:"<<c;
 p->right=create();
 return (p);
}

void preorder(struct node *t)
{
 if(t!=NULL)
  {
   cout<<" "<<t->data;
   preorder(t->left);
   preorder(t->right);
  }

}


void postorder(struct node *t)
{
 if(t!=NULL)
  {
   
   postorder(t->left);
   postorder(t->right);
   cout<<" "<<t->data;
  }

}


void inorder(struct node *t)
{
 if(t!=NULL)
  {
   
   inorder(t->left);
   cout<<" "<<t->data;
   inorder(t->right);
  }

}
int main()
{
 struct node *root;
 root=create();
 cout<<"\n....................PREORDER  :";
 preorder(root);
 cout<<"\n....................POSTORDER :";
 postorder(root);
 cout<<"\n....................INORDER   :";
 inorder(root);
 cout<<endl;
return 0;
}























