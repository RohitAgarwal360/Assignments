#include<iostream>
#define infy 999
#define MAX 50
using namespace std;

class prim
{
  private:
  int g[MAX][MAX],visited[MAX],distance[MAX],path[MAX],n,e,i,j,u,v,w,source,current,pos;
  
  public:
   prim()
   {
     for(i=0;i<MAX;i++)
     {
       for(j=0;j<MAX;j++)
       {
        visited[i]=path[i]=0;
       }
     }
   
   }
  void getdata();
  void primalgo();
  void print(); 

};

 void prim::getdata()
 {
   cout<<"\n Enter number of vertices:";
   cin>>n;
   for(i=0;i<n;i++)
   {
    for(j=0;j<n;j++)
    {
      g[i][j]=0;
    }
   }
 
   cout<<"\n Enter number of edeges:";
   cin>>e;
   for(i=1;i<=e;i++)	
   {
     cout<<"\n Enter edege in the form of(u,v,w):";
     cin>>u>>v>>w;
     g[u][v]=w;
     g[v][u]=w;
   
   }

 }
 
 
 
 void prim::print()
 {
   cout<<"\n Graph entered by user:";
   for(i=0;i<n;i++)
   {
     cout<<"\n";
     for(j=0;j<n;j++)
     {
      cout<<"\t"<<g[i][j];
     }
   }
   cout<<endl;
 
 }
 
 void prim::primalgo()
 {
   
   cout<<"\n Enter source vertex:";
   cin>>source;
   for(i=0;i<MAX;i++)
   {
 	   if(i==source)
 	   {
 	    distance[i]=0;
 	   }
 	   else
 	   {
 	    distance[i]=infy;
 	   }
   
   }
  
    current=source;
   for(j=0;j<n;j++)
   {
     	for(i=0;i<n;i++)
     	{
     	 	if(g[current][i]!=0 && visited[i]==0)
     	 	{
     	 	 	if(g[current][i]<distance[i])
     	 	 	{
     	 	 	  distance[i]=g[current][i];
     	 	 	  path[i]=current;
     	 	 	}
     	 	}
     	
     	}
   
   
    
    visited[current]=1;
    int min=infy;
    for(i=0;i<n;i++)
    {
     	if(distance[i]<min && visited[i]!=1)
        {
         	min=distance[i];
         	pos=i;
        }
    }
    
    current=pos;
   
  }
   
  cout<<"\n Distance Matrix:";
   for(i=0;i<n;i++)
   {
    cout<<"  "<<distance[i];
   
   }
  
  
  int sum=0;
  for(i=0;i<n;i++)
  {
    sum=sum+distance[i];
  }
  
  cout<<"\n Cost="<<sum;
  
  cout<<endl;
 }

 int main()
 {
   prim obj;
   obj.getdata();
   obj.print();
   obj.primalgo();
 
  return 0;
 }
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
