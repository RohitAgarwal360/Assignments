#include <iostream>
#include <set>
#include <string>
#include <cstdlib>
using namespace std;
int main()
{

    set<int> st;

    set<int>::iterator it;
    
     set<int>st1;
     set<int>::iterator it1;
     set<int>st2;
     set<int>::iterator it2;
    int choice, item,a;
    int flag=0;
    int flag1=0;
     
    while (1)

    {

        cout<<"\n---------------------"<<endl;

        cout<<"Set Implementation in Stl"<<endl;

        cout<<"\n---------------------"<<endl;

        cout<<"1.Insert Element into the Set"<<endl;

        cout<<"2.Delete Element of the Set"<<endl;

        cout<<"3.Size of the Set"<<endl;

        cout<<"4.Find Element in a Set"<<endl;

        cout<<"5.Dislplay by Iterator"<<endl;

        cout<<"6.Exit"<<endl;
        
        cout<<"7.Intersection of two sets"<<endl;
        
        cout<<"8.Enter the second set of elements"<<endl;
        
        cout<<"9.Display the second set using the itrator"<<endl;
        
        cout<<"10.Union Operation"<<endl;
        
        cout<<"11.difference between two sets"<<endl;

        cout<<"Enter your Choice: ";

        cin>>choice;

        switch(choice)

        {

        case 1:
            cout<<"Enter how many values you want to inset: ";
            cin>>a;
           for(int i=0;i<a;i++)
           { 
            cout<<"Enter value to be inserted: ";

            cin>>item;

            st.insert(item);
           } 

            break;

        case 2:

            cout<<"Enter the element to be deleted: ";

            cin>>item;

            st.erase(item);

            break;

        case 3:

            cout<<"Size of the Set: ";

            cout<<st.size()<<endl;

            break;

        case 4:

	    cout<<"Enter the element to be found: ";

	    cin>>item;

            it = st.find(item);

	    if (it != st.end())

                cout<<"Element "<<*it<<" found in the set" <<endl;

            else

                cout<<"No Element Found"<<endl;

            break;

        case 5:

            cout<<"Displaying Map by Iterator: ";

            for (it = st.begin(); it != st.end(); it++)

            {

                cout << (*it)<<" ";

            }

            cout<<endl;

            break;

        case 6:

            exit(1);

	    break;
        case 7:
            //for intersection logic
           
            
       cout<<"your intersection of two sets is: "<<endl; 
        /*for(it=st.begin(),it1=st1.begin();it!=st.end() && it1!=st1.end();it++,it1++)
              {
                if(*it==*it1)
                  {
                    cout<<*it1<<" ";
                   }
               }*/
          for(it=st.begin();it!=st.end();it++)
             {
              for(it1=st1.begin();it1!=st1.end();it1++)
                {
                  if(*it==*it1)
                  {
                    cout<<*it1<<" ";
                   }
                 }
               }              
                
        cout<<endl;
        
        
            break;
          
         case 8: 
            cout<<"Enter the 2nd set of elements"<<endl;
            cout<<"Enter how many values you want to inset: ";
            cin>>a;
           for(int i=0;i<a;i++)
           { 
            cout<<"Enter value to be inserted: ";

            cin>>item;

            st1.insert(item);
           }
         
            break;
            
          case 9:
             cout<<"Display using the iterator of second set"<<endl;
             //display
           for (it1 = st1.begin(); it1 != st1.end(); it1++)

            {

                cout << (*it1)<<" ";

            }

            cout<<endl;
            
           break; 
           
          case 10:
              cout<<"Union of two sets"<<endl;
            for(it=st.begin();it!=st.end();it++)
              {
                cout<<*it<<" ";
              } 
              
              for(it1=st1.begin();it1!=st1.end();it1++)
             {
                flag=0;
              for(it=st.begin();it!=st.end();it++)
                {
                  if(*it==*it1)
                  {
                    flag=1;
                   }
                }
                  if(flag==0)
                    cout<<*it1<<" "; 
                
               }              
                
        cout<<endl;
               
             break;  
             
         case 11:
                   //difference between two sets 
               cout<<"Difference between two sets is 1st-2nd : "<<endl;
              for(it=st.begin();it!=st.end();it++)
              {
                st2.insert(*it);
              }  
              for(it1=st1.begin();it1!=st1.end();it1++)
              {
                st2.erase(*it1);
              }  
              for(it2=st2.begin();it2!=st2.end();it2++)
              {
                cout<<*it2<<" "; 
              }
             cout<<endl;  
               
               break;        
          case 12:
                  //subset check
             for(it=st.begin();it!=st.end();it++)
              {
                for(it1=st1.begin();it1!=st1.end();it1++)
                 {
                   
                 }
              }       
             
        default:

            cout<<"Wrong Choice"<<endl;

        }

    }

    return 0;

}
