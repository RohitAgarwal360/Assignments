#include<iostream>
#include<set>
using namespace std;


int main()
{
  set<int> s1,s2,s3;
  set<int>::iterator it,it1,it2;
  int c,v,na,nb,cnt;
  bool flag;
  while(1)
  {
     cout<<"\n..............................MENU........................................";
     cout<<"\n 1.Add new element ";
     cout<<"\n 2.Remove element ";
     cout<<"\n 3.Display";
     cout<<"\n 4.Check element ";
     cout<<"\n 5.Size";
     cout<<"\n 6.Intersection ";
     cout<<"\n 7.Union ";
     cout<<"\n 8.Difference";
     cout<<"\n 9.Subset ";     
     cout<<"\n 10.Exit";
     cout<<"\n Enter your choice: ";
     cin>>c;
        switch(c)
        {
                case 1:
                {
                        cout<<"\n Enter element to be insert:";
                        cin>>v;
                        s1.insert(v);
                        break;
                }
        
                case 2:
                {
                        cout<<"\n Enter element to be remove:";
                        cin>>v;
                        s1.erase(v);
                        break;
                }
                
                 case 3:
                {
                        cout<<"\n Elements in the set are:"<<endl;
                        for(it=s1.begin();it!=s1.end();it++)
                        {
                          cout<<" "<<*it;
                        }
                        break;
                }
               
               
                case 4:
                {
                        cout<<"\n Enter element to be checked:";
                        cin>>v;
                        it=s1.find(v);
                                if(it!=s1.end())
                                {
                                  cout<<"\n Element "<<*it<<" found in set!! ";
                                }
                               else
                               cout<<"\n Element not found!!!"; 
                                
                        break;
                }
                
                case 5:
                {
                        cout<<"\n Size of set: "<<s1.size();
                        
                        break;
                }
                
                case 6:
                {
                      s1.clear();
                      s2.clear();
                      cout<<"\n Enter number of elements of set A: ";
                      cin>>na;
                      cout<<"\n Enter elements of set A:";
                      for(int i=0;i<na;i++)
                      {
                         cin>>v;
                         s1.insert(v);
                      }
                      cout<<"\n Enter number of elements of set B: ";
                      cin>>nb;  
                      cout<<"\n Enter elements of set B:";
                      for(int i=0;i<nb;i++)     //nb ?
                      {
                         cin>>v;
                         s2.insert(v);
                      }
                        cout<<"\n Elements in the set A are:";
                        for(it=s1.begin();it!=s1.end();it++)
                        {
                          cout<<" "<<*it;
                        }
                       
                         cout<<"\n Elements in the set B are:";
                        for(it=s2.begin();it!=s2.end();it++)
                        {
                          cout<<" "<<*it;
                        }
                        
                       cout<<"\n Intersection of set A  and set B :"; 
                       for(it1=s1.begin();it1!=s1.end();it1++)
                       {
                                for(it2=s2.begin();it2!=s2.end();it2++)
                                {
                                        if(*it1==*it2)
                                        {
                                          cout<<"  "<<*it1;
                                        }
                                }
                       }
                       
                        break;
                }
                
                case 7:
                {
                       s1.clear();
                      s2.clear();
                      cout<<"\n Enter number of elements of set A: ";
                      cin>>na;
                      cout<<"\n Enter elements of set A:";
                      for(int i=0;i<na;i++)
                      {
                         cin>>v;
                         s1.insert(v);
                      }
                      cout<<"\n Enter number of elements of set B: ";
                      cin>>nb;  
                      cout<<"\n Enter elements of set B:";
                      for(int i=0;i<nb;i++)
                      {
                         cin>>v;
                         s2.insert(v);
                      }
                        cout<<"\n Elements in the set A are:";
                        for(it=s1.begin();it!=s1.end();it++)
                        {
                          cout<<" "<<*it;
                        }
                       
                         cout<<"\n Elements in the set B are:";
                        for(it=s2.begin();it!=s2.end();it++)
                        {
                          cout<<" "<<*it;
                        }
                        
                        cout<<"\n Union of set A and set B :";
                        
                        
                         for(it1=s1.begin();it1!=s1.end();it1++)
                       {
                                for(it2=s2.begin();it2!=s2.end();it2++)
                                {
                                       if(*it1!=*it2)
                                       {
                                          s1.insert(*it2);
                                       }           
                                }
                       }
                         for(it=s1.begin();it!=s1.end();it++)
                        {
                          cout<<"  "<<*it;
                        }
                        
                        break;
                }
                
                case 8:
                {   
                       s1.clear();
                      s2.clear();
                      cout<<"\n Enter number of elements of set A: ";
                      cin>>na;
                      cout<<"\n Enter elements of set A:";
                      for(int i=0;i<na;i++)
                      {
                         cin>>v;
                         s1.insert(v);
                      }
                      cout<<"\n Enter number of elements of set B: ";
                      cin>>nb;  
                      cout<<"\n Enter elements of set B:";
                      for(int i=0;i<nb;i++)
                      {
                         cin>>v;
                         s2.insert(v);
                      }
                        cout<<"\n Elements in the set A are:";
                        for(it=s1.begin();it!=s1.end();it++)
                        {
                          cout<<" "<<*it;
                        }
                       
                         cout<<"\n Elements in the set B are:";
                        for(it=s2.begin();it!=s2.end();it++)
                        {
                          cout<<" "<<*it;
                        }
                        
                        cout<<"\n Difference between set A and B i.e.(A-B): ";
                         for(it1=s1.begin();it1!=s1.end();it1++)
                       {
                                flag=false;
                                for(it2=s2.begin();it2!=s2.end();it2++)
                                {
                                        if((*it1)==(*it2))
                                        {
                                           flag=true;                  
                                        }
                                }
                          if(flag==false)      
                          cout<<"  "<<*it1;
                         
                       }
                       
                        
                        break;
                }
                
                case 9:
                {
                      cnt=0;
                      s1.clear();
                      s2.clear();
                      cout<<"\n Enter number of elements of set A: ";
                      cin>>na;
                      cout<<"\n Enter elements of set A:";
                      for(int i=0;i<na;i++)
                      {
                         cin>>v;
                         s1.insert(v);
                      }
                      cout<<"\n Enter number of elements of set B: ";
                      cin>>nb;  
                      cout<<"\n Enter elements of set B:";
                      for(int i=0;i<nb;i++)
                      {
                         cin>>v;
                         s2.insert(v);
                      }
                        cout<<"\n Elements in the set A are:";
                        for(it=s1.begin();it!=s1.end();it++)
                        {
                          cout<<" "<<*it;
                        }
                       
                         cout<<"\n Elements in the set B are:";
                        for(it=s2.begin();it!=s2.end();it++)
                        {
                          cout<<" "<<*it;
                        }
                        
                        
                        
                          for(it1=s1.begin();it1!=s1.end();it1++)
                       {
                              
                                for(it2=s2.begin();it2!=s2.end();it2++)
                                {
                                        if((*it1)==(*it2))
                                        {
                                           cnt++;                  
                                        }
                                }
                          if(cnt==nb)      
                          flag=true;
                          else
                          flag=false;
                       }
                        
                        if(flag==true)
                        cout<<"\n B IS subset of A!!";
                        else
                        cout<<"\n B is NOT subset of A!!";
                        
                        
                        break;
                }
                
               
                
                case 10:
                {
                        return 0;
                        
                }
                default:
                {
                        cout<<"\n Wrong choice!!";
                        break;
                }
        }
  
  
  
  
  }


 return 0;
}
