#include<iostream>
#define MAX 10
using namespace std;

struct S
{
  int uid;
  long int num;
};


class Directory
{
	private:
		  S d[MAX];
	public:
		Directory()
		{
			for(int i=0;i<MAX;i++)
			{
			  d[i].uid=-1;
			  d[i].num=-1;
			}
		
		}
		int hash(int uid);
		void linearp(int key,int uid,long int data);
		void display();
		void search(int key,int uid);

};

int Directory::hash(int uid)
{
	int key;
	key=uid%10;
	return key;
	
}

void Directory::linearp(int key,int uid,long int data)
{

	int flag=0,i,cnt=0;
	if(d[key].uid==-1)
	{
	 d[key].uid=uid;
	 d[key].num=data;
	}
	else
	{
	  i=0;
	  while(i<MAX)
	  {
	  	if(d[i].uid!=-1)
	  		cnt++;
	  		
	  	i++;
	  	
	  }
	 
	  
	  if(cnt==MAX)
	  {
	   cout<<"\n Hash table is FULL!! Hence can't insert "<<data;
	  
	  }
	for(i=key+1;i<=MAX;i++)
	{  i=i%MAX;
		
		if(d[i].uid==-1)
		{
			d[i].uid=uid;
			d[i].num=data;
			flag=1;
			break;
		}
	
		
	
	}

	/*for(i=0; i<key && flag==0;i++)
	{
		if(d[i].uid==-1)
		{
			d[i].uid=uid;
			d[i].num=data;
			flag=1;
			break;
		}
	
	  }*/
     }
}

void Directory::search(int key,int uid)
{
    int c=1;
    int b=0; 
    for(int i=key;i<MAX;i++)
    {
     	if(d[i].uid==uid)
     	{
     		cout<<"\n Telephone no.found Successfully!!";
     		cout<<"\n of UID:"<<d[i].uid<<" at key:"<<i<<endl;
     		b=1;
     	        break;
     	}
        
        else
        {
        	c=0;
     		
     	}
        
    }

	for(int i=0;i<key;i++)
	if(d[i].uid==uid)
     	{
     		cout<<"\n Telephone no.found Successfully!!";
     		cout<<"\n of UID:"<<d[i].uid<<" at key:"<<i<<endl;
     		b=1;
     	        break;
     	}
        
        else
        {
     	         c=0;
     		
     	}
        
    if(c==0 && b!=1)
    {
      cout<<"\n Telephone no. NOT found!! of UID :"<<uid;
    }







}



void Directory::display()
{	
	cout<<"\n................Telephone Directory................. "<<endl;
	cout<<"\n\n\tKEY"<<"\tUID"<<"\tTelephone no.";
	for(int i=0;i<MAX;i++)
	{
		cout<<"\n\t"<<i<<"\t"<<d[i].uid<<"\t"<<d[i].num;
	
	}


}





int main()
{
int c;
int u,k;
long int tn;
Directory d1;
while(1)
{
	cout<<"\n..................MENU......................";
	cout<<"\n 1.Insert \n 2.Display \n 3.Search \n 4.Exit"<<endl;
	cin>>c;
	
	switch(c)
	{
		case 1:
			cout<<"\n Enter UID and Telepnone no.";
			cin>>u>>tn;
			k=d1.hash(u);
			d1.linearp(k,u,tn);
			break;
		case 2:
			d1.display();
			break;
			
		case 3:
               		cout<<"\n Enter UID to be search:";
               		cin>>u;
               		k=d1.hash(u);
               		d1.search(k,u);
               		break;
		
		case 4:
			return 0;
	}
}


return 0;
}















