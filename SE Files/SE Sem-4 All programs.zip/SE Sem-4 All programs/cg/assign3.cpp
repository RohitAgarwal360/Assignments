#include<iostream>
#include<graphics.h>
#include<math.h>
#include<stdlib.h>
using namespace std;
 void dda(float x1,float y1,float x2,float y2)
 {
	float dx,dy,x=x1,y=y1,m;
	int i;
	dx=x2-x1;
	dy=y2-y1;
	if(abs(dx)>=abs(dy))
	m=abs(dx);
	else m=abs(dy);
	putpixel((int)x,(int)y,15);
	for(i=1;i<=m;i++)
	{    
		x=x+dx/m;
		y=y+dy/m;
		putpixel((int)x,(int)y,15);
	}
 }

 void dda2(float x1,float y1,float x2,float y2) //dotted line
 {
	float dx,dy,x=x1,y=y1,m;
	int i,j;
	dx=x2-x1;
	dy=y2-y1;
	if(abs(dx)>=abs(dy))
	m=abs(dx);
	else m=abs(dy);
	//putpixel((int)x,(int)y,15);
     	for(i=1,j=0;i<=m;i++)
	{  
	     {   
		x=x+dx/m;
		y=y+dy/m;
	     	if(j%7==0)
		putpixel((int)x,(int)y,15);
	     }
	   j++;
	  	
	}
 }

 void dda3(float x1,float y1,float x2,float y2) //dotted dash
 {
	float dx,dy,x=x1,y=y1,m;
	int i,j,flag=0;
	dx=x2-x1;
	dy=y2-y1;
	if(abs(dx)>=abs(dy))
	m=abs(dx);
	else m=abs(dy);
	putpixel((int)x,(int)y,15);
     	for(i=1,j=0;i<=m;i++)
	{  flag=0;
	     {   
		x=x+dx/m;
		y=y+dy/m;
	     	if(j%2==0)
		{putpixel((int)x,(int)y,15);
		 flag=1;
		}
		if(j%3==0 && flag!=1)
		{
		 putpixel((int)x,(int)y,15);
		}
	     }
	   j++;
	  	
	}
 }
 
void dda4(float x1,float y1,float x2,float y2) //dash
 {
	float dx,dy,x=x1,y=y1,m;
	int i,j,flag=0;
	dx=x2-x1;
	dy=y2-y1;
	if(abs(dx)>=abs(dy))
	m=abs(dx);
	else m=abs(dy);
	putpixel((int)x,(int)y,15);
     	for(i=1,j=0;i<=m;i++)
	{  flag=0;
	        
		x=x+dx/m;
		y=y+dy/m;
	     	if(j%7==0)
		{//putpixel((int)x,(int)y,15);
		 flag=1;
		}
		if(flag!=1)
		{
		 putpixel((int)x,(int)y,15);
		}
	     
	   j++;
	  	
	}
 }
 
 void dda5(float x1,float y1,float x2,float y2,int th) //thick
 {
	float dx,dy,x=x1,y=y1,m,p,q;
	int i,j;
	dx=x2-x1;
	dy=y2-y1;
	if(abs(dx)>=abs(dy))
	m=abs(dx);
	else {m=abs(dy);}
	//putpixel((int)x,(int)y,15);
     	for(i=1,j=0;i<=m;i++)
	{  
	   	x=x+dx/m;
		y=y+dy/m;
	        putpixel((int)x,(int)y,YELLOW);
	     	p=x;
		q=y;
              	     	
		for(int k=0;k<th;k++)
		 {
		  if((dx>0 && dy<0) || (dx<0 && dy>0))
	          { 
                    putpixel((int)++p,(int)++q,BLUE);
		  }
		  delay(5);
		  if((dx>0 && dy>0) || (dx<0 && dy<0))
		  {
		    putpixel((int)--p,(int)++q,RED);  
		  }
		 if(dx==0)
		  { putpixel((int)++p,(int)q,12);
		   }
		 if(dy==0)
		  {
		   putpixel((int)p,(int)++q,12);
		  } 
	 }
	     j++;  	
	}
 }

 
 
 int main()
{
	float x1,x2,y1,y2;
	int ch,st,th;
	cout<<"Enter end points of line(x1,y1,x2,y2)";
	cin>>x1>>y1>>x2>>y2;
	cout<<"\nMENU IS HERE:";
	cout<<"\n1)simple line\n2)dotted line\n3)dotted dash\n4)dash\n5)thick\n";
	cin>>st;
	if(st==5)
	 {
	  cout<<"\nEnter the thickness of a line: ";
          cin>>th;
	  }
	int gd=DETECT,gm=0;
	initgraph(&gd,&gm,(char *)"");
  
   {	
	switch(st)
 {
    case 1:
      {	//for simple line or solid
	dda(x1,y1,x2,y2);
	break;
       }	
    case 2:
       {//dotted line
        dda2(x1,y1,x2,y2);
        break;
       } 
    case 3:
       {//dotted dash
        dda3(x1,y1,x2,y2);
        break; 
       } 
    case 4:
       { //dash
        dda4(x1,y1,x2,y2);
        break;
       }
    case 5:
       { //thick
       
       dda5(x1,y1,x2,y2,th);
       break;
       }           
   }
  }
  	
	getch();
	closegraph();
	return 0;
}
