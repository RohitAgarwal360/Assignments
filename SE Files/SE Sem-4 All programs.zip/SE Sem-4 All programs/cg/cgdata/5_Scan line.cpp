//       Assignment No.   :-Polygon Filling- Scan line                                  
//      

#include<conio.h>
#include<iostream.h>
#include<graphics.h>
#include<dos.h>

class shape
{
    public:
	float ver,xc[10],yc[10];
	int x1,y1;
    public:
	int choice;
	void getmouse(int *x1,int *y1,int *b1);
	void initmouse();
	void verscan();
	void dpoly();
	void ffill(int,int,int);
	void bfill(int,int,int);
	void scanline();

};

void shape::initmouse()
{
   asm{
	mov ax,0;
	int 0x33;
      }
   asm{
	mov ax,1;
	int 0x33;
      }
}
void shape::getmouse(int *x1,int *y1,int *b1)
{
 int x,y,b=0;
   asm{
	mov ax,3
	int 0x33

	mov b,bx
	mov x,cx
	mov y,dx
      }
 *b1=b;
 *x1=x;
 *y1=y;
}


void shape::dpoly()
{
	int i;
	for(i=0;i<ver;i++)
	{       if(choice==1)
		setcolor(i+2);
		line(xc[i],yc[i],xc[i+1],yc[i+1]);
		delay(10);
	}
}
void shape::verscan()
{
	int i=0,x,y,button=0;
	cout<<"\n\t\t ENTER NO OF VERTICES...";
	cin>>ver;
	cout<<"\n\n\t\tenter vertices..";
	delay(500);
	cleardevice();
	initmouse();
	while(1)
	{
	  getmouse(&x,&y,&button);
	  if(button==1)
	  {
	   xc[i]=x;
	   yc[i]=y;
	   delay(500);
	   i++;
	  }
	  if(i==ver)
	     break;
       }

      xc[i]=xc[0];
      yc[i]=yc[0];

}
void shape::ffill(int x,int y,int col)
{
	int curr=getpixel(x,y);
	if(curr==0)
	{
		putpixel(x,y,col);
		delay(5);
		ffill(x-1,y,col);
		ffill(x+1,y,col);
		ffill(x,y-1,col);
		ffill(x,y+1,col);
	}



}
void shape::bfill(int x,int y,int col)
{
	int curr=getpixel(x,y);
	if((curr!=col)&&(curr!=15))
	{
		putpixel(x,y,col);
		delay(5);
		bfill(x+1,y,col);
		bfill(x,y+1,col);
		bfill(x-1,y,col);
		bfill(x,y-1,col);
	}


}

void shape::scanline()
{
	int inter_x[10],y,ymax=0,ymin=480;
	float m[10],dx,dy,temp;
	int colour;
	for(int i=0;i<ver;i++)
	{
		if(yc[i]>=ymax)
			ymax=yc[i];
		if(yc[i]<=ymin)
			ymin=yc[i];
		dx=xc[i+1]-xc[i];
		dy=yc[i+1]-yc[i];
		if(dx==0)
			m[i]=0;
		if(dy==0)
			m[i]=1;
		if(dx!=0&&dy!=0)
			m[i]=dx/dy;
	}
	int cnt;
	cout<<"\nEnter the Color:   ";
	 cin>>colour;
	setcolor(colour);
	for(y=ymax;y>=ymin;y--)
	{
		cnt=0;
		for(i=0;i<ver;i++)
		{
			if((yc[i]>y&&yc[i+1]<=y)||(yc[i]<=y&&yc[i+1]>y))
			{
				inter_x[cnt]=(xc[i]+(m[i]*(y-yc[i])));
				cnt++;
			}
		}
		for(int j=0;j<cnt-1;j++)
		{
			for(i=0;i<cnt-1;i++)
			{
				if(inter_x[i]>inter_x[i+1])
				{
					temp=inter_x[i];
					inter_x[i]=inter_x[i+1];
					inter_x[i+1]=temp;
				}
			}
		}
		for(i=0;i<cnt-1;i+=2)
		{
			line(inter_x[i],y,inter_x[i+1],y);
			delay(55);
		}
	}



}
void main()
{
	int gm,gd,i,seedx,seedy,x,y;
	char ch='y';
	shape p;
	detectgraph(&gm,&gd);
	initgraph(&gm,&gd,"c:\\tc\\bgi");
	do
	{

		cleardevice();
		cout<<"\nSCANLINE FILL ALGORITHM!!!!";
		p.verscan();
		cleardevice();
		p.dpoly();
		p.scanline();
		getch();
		cout<<"\nPress 'y' to continue else 'n'....";
		ch=getch();
	}while((ch=='y')||(ch=='Y'));
}