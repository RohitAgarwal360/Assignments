

    #include<stdio.h>
//    #include<conio.h>
    #include<graphics.h>
    int main()
    {
    int x1,y1,x2,y2;
    int gd=DETECT,gm=0;
     //   x1=x2=y2=y1=50;
//    clrscr();
    initgraph(&gd,&gm,(char*)"");
    putpixel(100,200,BLUE);
    delay(1000);
    //circle(100,200,100); 
 // 100,200 is a center point of the circle,so u less the rectangle value from this axis
   // rectangle(x1,y1,x2,y2);
    getch();
    closegraph();
   
    //getch();
    //while(1)
    {
    getch();
    }
    return 0;
    }


