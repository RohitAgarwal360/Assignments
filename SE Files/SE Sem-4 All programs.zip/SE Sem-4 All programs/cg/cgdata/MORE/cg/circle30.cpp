#include<graphics.h>
#include<iostream>
#include<stdlib.h>
#include<math.h>
using namespace std;
 class pixel
    {
      int dx,dy,x1,x2,y1,y2,a1,a2,length,r,r2,d;
        float x,y;
public:
	pixel()
		{
			x=y=x1=x2=y1=y2=0;
		}
	
	void bresenham();
	void bresenham1();
	void getdata();
	void dda(float,float,float,float);
     };
void pixel::getdata()
{
  cout<<"Entered the co-ordinates of centre of circle:\n x=100 \n y=100 \n Radius of grater circle=50 \n Radius of smaller circle=25\n\n\n\n";
 x1=100;
 y1=100;
 r=50; 
 r2=25;
}

void pixel::dda(float x1,float y1,float x2,float y2)
 {
	float dx,dy,x=x1,y=y1,m;
	int i;
	dx=x2-x1;
	dy=y2-y1;
	if(abs(dx)>=abs(dy))
	m=abs(dx);
	else m=abs(dy);
	putpixel((int)x,(int)y,RED);
	for(i=1;i<=m;i++)
	{
		x=x+dx/m;
		y=y+dy/m;
	//	delay(100);
		putpixel((int)x,(int)y,RED);
	}
 }


void pixel::bresenham()     	
{
 d=3-(2*r);
 x=0; y=r;
 do{
  
   if(d<0)
    {
      d=d+4*(x)+6;
     }
    else{
     d=d+4*(x-y)+10;
     y=y-1;
     }
   x++;
 // delay(100); 
   putpixel(x1+x,y1+y,RED);
   putpixel(x1+y,y1+x,RED);
   putpixel(x1-y,y1+x,RED);
   putpixel(x1+x,y1-y,RED);
   putpixel(x1-x,y1-y,RED);
   putpixel(x1-y,y1-x,RED);
   putpixel(x1+y,y1-x,RED);
   putpixel(x1-x,y1+y,RED);
   
   }while(x<y);
 }

void pixel::bresenham1()     	
{
 d=3-(2*r2);
 x=0; y=r2;
 do{
  
   if(d<0)
    {
      d=d+4*(x)+6;
     }
    else{
     d=d+4*(x-y)+10;
     y=y-1;
     }
   x++;
  
   putpixel(x1+x,y1+y,RED);
   putpixel(x1+y,y1+x,RED);
   putpixel(x1-y,y1+x,RED);
   putpixel(x1+x,y1-y,RED);
   
   putpixel(x1-x,y1-y,RED);
   putpixel(x1-y,y1-x,RED);
   putpixel(x1+y,y1-x,RED);
   putpixel(x1-x,y1+y,RED);
  // delay(100);
   }while(x<y);
 }

 
int main()
{
 pixel obj;
   obj.getdata();
   int gd=DETECT,gm=0;
   initgraph(&gd,&gm,(char *)" ");            
   obj.bresenham();
   obj.bresenham1();
   obj.dda(100,50,144,125); 
   obj.dda(144,125,56,125);
   obj.dda(56,125,100,50);
   putpixel(100,100,RED);
   
   getch();
   closegraph();
 return 0;
 }  
   
 
        
