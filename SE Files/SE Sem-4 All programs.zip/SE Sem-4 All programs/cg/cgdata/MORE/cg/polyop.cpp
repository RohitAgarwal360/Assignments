#include<iostream>
#include<graphics.h>
#include<math.h>
using namespace std;
 int a;
 int tx,ty;
 int m;
 int angle;
void drawpoly(int x[],int y[],int cn)
{
for(int i=0;i<cn-1;i++)
   {
   
    //cout<<x[i]<<" "<<y[i]<<endl;
    line(x[i],y[i],x[i+1],y[i+1]);
   }
   line(x[0],y[0],x[cn-1],y[cn-1]);

if(a==1)
 {
   for(int i=0;i<=cn;i++)
   {
     x[i]*=m;
     y[i]*=m;
    } 
  for(int i=0;i<cn-1;i++)
   {
   
    //cout<<x[i]<<" "<<y[i]<<endl;
    line(x[i],y[i],x[i+1],y[i+1]);
   }
   line(x[0],y[0],x[cn-1],y[cn-1]);  
  }

if(a==2)
{
  for(int i=0;i<=cn;i++)
    {
     x[i]+=tx;
     y[i]+=ty;
    } 
  for(int i=0;i<cn-1;i++)
   {
   
    //cout<<x[i]<<" "<<y[i]<<endl;
    line(x[i],y[i],x[i+1],y[i+1]);
   }
   line(x[0],y[0],x[cn-1],y[cn-1]);
}

if(a==3)
 {
   for(int i=0;i<=cn;i++)
    {
     x[i]=x[i]*cos(angle*3.14/180)-y[i]*sin(angle*3.14/180);
     y[i]=x[i]*sin(angle*3.14/180)+y[i]*cos(angle*3.14/180);
    }
    
   for(int i=0;i<cn-1;i++)
   {
   
    //cout<<x[i]<<" "<<y[i]<<endl;
    line(x[i],y[i],x[i+1],y[i+1]);
   }
   line(x[0],y[0],x[cn-1],y[cn-1]); 
     
  }
}
int main()
 {
  int cn;
  cout<<"Enter how many co-ordinates you want to enter :";
  cin>>cn;
  int x[cn+1];
  int y[cn+1];
  for(int j=0;j<cn+1;j++)
  { 
   x[j]=0;
   y[j]=0;
   }
  

  cout<<"Enter you coordinates : \n";  
  for(int i=0;i<cn;i++)
   {

   cin>>x[i]>>y[i];  
   }
   
  /* for(int i=0;i<cn;i++)
   {
    cout<<x[i]<<" "<<y[i]<<endl;
    }*/ 
    
// cout<<"this is in cn_+1"<<x[cn+1];    //garbage value
  cout<<"Enter the choice you want :"<<endl;
  cout<<"1)scaling \n2)transformation\n3)Rotation"<<endl;
  cout<<"Enter any other number only for polygon display\n";
  cin>>a;
 if(a==1)
 { 
   
  cout<<"Enter your scaling factor"<<endl;
  cin>>m;
  
   
 
    
 } 
 if(a==2)
  {
   
   cout<<"Enter your transformation factor for x-coordinate"<<endl;
   cin>>tx;
   cout<<"Enter your transformation factor for y-coordinate"<<endl;
   cin>>ty;
   
  
   } 
 if(a==3)
  {
   cout<<"Enter the angel in degree"<<endl;
   cin>>angle;
    
   
   
  }   
 

    
 int gd=DETECT,gm=0;
 initgraph(&gd,&gm,(char *)"");
 drawpoly(x,y,cn);   
 getch();
 closegraph(); 
 

  return 0;
  }
