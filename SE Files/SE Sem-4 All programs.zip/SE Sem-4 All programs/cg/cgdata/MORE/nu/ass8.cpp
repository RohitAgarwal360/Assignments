#include <iostream>
#include <graphics.h>
using namespace std;

void bfill(int x,int y,int fill,int border)
{
	if((getpixel(x,y)!=border)&&(getpixel(x,y)!=fill))
	{
		delay(5);
		putpixel(x,y,fill);

		bfill(x+1, y-1,fill,border);
        	bfill(x+1, y+1,fill,border);
        	bfill(x-1, y-1,fill,border);
        	bfill(x-1, y+1,fill,border);        	
	}
}


void floodFill(int x, int y, int old, int fill)
{
	int current;
	current=getpixel(x,y);
	if(current==old)
	{
		putpixel(x,y,fill);
		delay(5);
		floodFill(x+1,y,old,fill);
		floodFill(x-1,y,old,fill);
		floodFill(x, y+1,old,fill);
		floodFill(x,y-1,old,fill);
	}
}

int main()
{
int ch;
do
{
cout<<"\n 1.Flood fill";
cout<<"\n 2.Boundary fill";
cout<<"\n Enter ur choice";
cin>>ch;
  switch(ch)
  {

    case 1:
		{
		int x,y,o=0;
		
		int gDriver=DETECT,gmode;
		initgraph(&gDriver,&gmode, " ");
		 rectangle(100,100,200,200);
		x=(100+150)/2;
		y=(100+200)/2;
		floodFill(x,y,o,4);
		
		closegraph();
		}
		break;
   case 2:    {
   int gd=DETECT,gm;
	initgraph(&gd,&gm,"  ");
	rectangle(10,50,50,10);
	bfill(11,12,MAGENTA,WHITE);
	
	closegraph();
	}
	break;
			
 default:  cout<<"\n invalid choice";
        break;
}
}while(ch!=3);		
		
return 0;
}		
		

