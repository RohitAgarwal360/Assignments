#include<iostream>
#include<graphics.h>
#include<math.h>
using namespace std;
void drawpoly(int x[],int y[],int cn)
{



for(int i=0;i<cn-1;i++)
   {
   
    //cout<<x[i]<<" "<<y[i]<<endl;
    line(x[i],y[i],x[i+1],y[i+1]);
   }
   line(x[0],y[0],x[cn-1],y[cn-1]);

}


int main()
 {
  int cn;
  
  cout<<"Enter how many co-ordinates you want to enter :";
  cin>>cn;
  int x[cn+1];
  int y[cn+1];
  for(int j=0;j<cn+1;j++)
  { 
   x[j]=0;
   y[j]=0;
   }
  

  cout<<"Enter you coordinates : \n";  
  for(int i=0;i<cn;i++)
   {

   cin>>x[i]>>y[i];  
   }
   
  /* for(int i=0;i<cn;i++)
   {
    cout<<x[i]<<" "<<y[i]<<endl;
    }*/ 
    
 int gd=DETECT,gm=0;
 initgraph(&gd,&gm,(char *)"");
 drawpoly(x,y,cn);   
 getch();
 closegraph(); 
  return 0;
  }
