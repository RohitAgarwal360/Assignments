#include<graphics.h>
#include<iostream>
#include<stdlib.h>
#include<math.h>
#include<termios.h>
using namespace std;
 class pixel
    {
      int dx,dy,x1,x2,y1,y2,a1,a2,length,r,d;
        float x,y;
public:
	pixel()
		{
			x=y=x1=x2=y1=y2=0;
		}
	
	void bresenham();
	void getdata();
     };
void pixel::getdata()
{
  cout<<"Enter the co ordinates of centre of circle:\n x=";
  cin>>x1;
  cout<<"\ny=";
  cin>>y1; 	
  cout<<"Enter the radius of circle\n :";
  cin>>r;
}
void pixel::bresenham()     	
{
 d=3-(2*r);
 x=0; y=r;
 do{
  // putpixel(x,y,RED);
   if(d<0)
    {
      d=d+4*(x)+6;
     }
    else{
     d=d+4*(x-y)+10;
     y=y-1;
     }
   x++;   
   putpixel(x1+x,y1+y,RED);//
   putpixel(x1+y,y1+x,YELLOW);//
   putpixel(x1-y,y1+x,RED);
   putpixel(x1+x,y1-y,YELLOW);//
   putpixel(x1-x,y1-y,RED);//
   putpixel(x1-y,y1-x,YELLOW);
   putpixel(x1+y,y1-x,RED);//
   putpixel(x1-x,y1+y,YELLOW);//
   }while(x<y);
  // floodfill(x1,y1,12);
   //floodfill(0.45*maxx,0.45*maxy,12);
 }
 
int main()
{
 pixel obj;
   obj.getdata();
   int gd=DETECT,gm=0;
   initgraph(&gd,&gm,(char *)" ");            
   obj.bresenham();
    //floodfill(x1,y1,12);
   getch();
   closegraph();
 return 0;
 }  
   
 
        
