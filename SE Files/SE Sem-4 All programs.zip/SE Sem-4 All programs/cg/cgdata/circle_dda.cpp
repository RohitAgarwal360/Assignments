#include<iostream>
using namespace std;
#include<graphics.h>
#include<math.h>
class circlee
{
 public:
  float r;
  int x,y;
circlee()
{
 r=0;
 x=y=80;
}

void circle_bresenham(float,int ,int);
void circle_dda(float,int ,int);
void line_bresenham(float, float ,float, float );
};


void circlee::circle_bresenham(float r,int x1,int y1)
{
 float d;
 d=3-(2*r);
 int x=0,y=r;
 do
 {
  putpixel(x1,y1,WHITE);
  if(d<0)
  {
   d=(d+4*x+6);
  }
  else
  {
   d=(d+4*(x-y)+10);
   y--;
  } 
 x++;
 putpixel(x1+x,y1+y,WHITE);
 putpixel(x1+y,y1+x,WHITE);
 putpixel(x1-y,y1+x,WHITE);
 putpixel(x1+x,y1-y,WHITE);
 putpixel(x1-x,y1-y,WHITE);
 putpixel(x1-y,y1-x,WHITE);
 putpixel(x1+y,y1-x,WHITE);
 putpixel(x1-x,y1+y,WHITE);
 
 }while(x<y);

}


void circlee::circle_dda(float r,int x1,int y1)
{

}

 void circlee::line_bresenham(float  x1,float y1,float  x2,float  y2)
        {	float  length;
 
 if( abs(x2-x1) >= abs(y2-y1) )
 {
  length= abs(x2-x1);
 }
 else
 {
  length= abs(y2-y1);
 }
 
 float X=(x2-x1)/length;
 float Y=(y2-y1)/length;
 
 float x=x1+0.5f;
 float y=y1+0.5f;
 
 int i=0;
 while(i<= length)
 {
  putpixel(floor(x),floor(y),WHITE);
  x=x+X;
  y=y+Y;
  i++;
 }
 
}  



int main()
{
circlee c;
int gd=DETECT,gm=0;
cout<<"\nEnter radius of circle :";
cin>>c.r;
cout<<"\nEnter x and y coordinates of centre :";
cin>>c.x>>c.y;

initgraph(&gd,&gm,NULL);
c.circle_bresenham(c.r,c.x,c.y);   //50,80,80

c.circle_bresenham(c.r/2,c.x,c.y); //25,80,80

int b_d,l_d,r_d;
 int bd=(c.r*c.r)-((c.r/2)*(c.r/2));
b_d=sqrt(bd);

c.line_bresenham(c.x-b_d , c.y+(c.r/2) ,c.x , (c.y-c.r) );

c.line_bresenham(c.x-b_d , c.y+(c.r/2) ,(c.x+b_d) ,c.y+(c.r/2) );

c.line_bresenham(c.x , (c.y-c.r) , (c.x+b_d) ,c.y+(c.r/2) );

getch();
closegraph();

return 0;

}
