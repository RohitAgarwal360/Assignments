#include<iostream>
using namespace std;
#include<graphics.h>
#include<math.h>
class circlee
{
 public:
  float r;
  int x,y;
circlee()
{
 r=0;
 x=y=80;
}

void circle_bresenham(float,int ,int);
void line_dda(float, float ,float, float );
};


void circlee::circle_bresenham(float r,int x1,int y1)
{
 float d;
 d=3-(2*r);
 int x=0,y=r;
 do
 {
  putpixel(x1,y1,WHITE);
  if(d<0)
  {
   d=(d+4*x+6);
  }
  else
  {
   d=(d+4*(x-y)+10);
   y--;
  } 
 x++;
 putpixel(x1+x,y1+y,WHITE);
 putpixel(x1+y,y1+x,WHITE);
 putpixel(x1-y,y1+x,WHITE);
 putpixel(x1+x,y1-y,WHITE);
 putpixel(x1-x,y1-y,WHITE);
 putpixel(x1-y,y1-x,WHITE);
 putpixel(x1+y,y1-x,WHITE);
 putpixel(x1-x,y1+y,WHITE);
 
 }while(x<y);

}




void circlee::line_dda(float  x1,float y1,float  x2,float  y2)
        {	
        float dx,dy,x=x1,y=y1,m;
	int i;
	dx=x2-x1;
	dy=y2-y1;
	if(abs(dx)>=abs(dy))
	m=abs(dx);
	else m=abs(dy);
	putpixel((int)x,(int)y,15); //color  range 0 to 256
	for(i=1;i<=m;i++)
	{
		x=x+dx/m;
		y=y+dy/m;
		putpixel((int)x,(int)y,15);
		delay(100);
	}
 }
 
  



int main()
{
circlee c;
int gd=DETECT,gm=0;
cout<<"\nEnter radius of circle :";
cin>>c.r;
cout<<"\nEnter x and y coordinates of centre :";
cin>>c.x>>c.y;

initgraph(&gd,&gm,NULL);

c.circle_bresenham(c.r,c.x,c.y);   //50,80,80

c.circle_bresenham(c.r/2,c.x,c.y); //25,80,80

int b;

int bd=(c.r*c.r)-((c.r/2)*(c.r/2)); //bd=r^2-(r/2)*(r/2)
 
b=sqrt(bd);

c.line_dda(c.x-b , c.y+(c.r/2) ,c.x , (c.y-c.r) );

c.line_dda(c.x-b , c.y+(c.r/2) ,(c.x+b) ,c.y+(c.r/2) );

c.line_dda(c.x , (c.y-c.r) , (c.x+b) ,c.y+(c.r/2) );

getch();
closegraph();

return 0;

}
