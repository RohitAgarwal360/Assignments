 #include<iostream>
 #include<graphics.h>
 #include<math.h>
 using namespace std;
 void dda(float x1,float y1,float x2,float y2)
 {
	float dx,dy,x=x1,y=y1,m;
	int i;
	dx=x2-x1;
	dy=y2-y1;
	if(abs(dx)>=abs(dy))
	m=abs(dx);
	else m=abs(dy);
	putpixel((int)x,(int)y,15); //color  range 0 to 256
	for(i=1;i<=m;i++)
	{
		x=x+dx/m;
		y=y+dy/m;
		putpixel((int)x,(int)y,15);
	}
 }
 void bress(float x1,float y1,float x2,float y2)
 {
 	int x,y,end,inc=0,p,dx=abs(x2-x1),dy=abs(y2-y1);
 	
 	if(dx>dy)
 	{
 		p=2*dy-dx;
  		if(x1<x2)
  		{
   			x=x1;y=y1;end=x2;
   			if(y1<y2)inc=1;
   			if(y1>y2)inc=-1;
  		}
  		else
  		{
   			x=x2;y=y2;end=x1;
   			if(y2<y1)inc=1;
  			if(y2>y1)inc=-1;
  		}
  		while(x<=end)
  		{
  			putpixel(x,y,15);

  			if(p<0) p=p+2*dy;
  			else
  			{
  				y=y+inc;p=p+2*(dy-dx);
   			}
  			x++;
  			
  		}
 	}
    /*else condition is same but the x is replaced by y and the conditions of c and current remains the same  dx <==> dy  */
 	
 	else
	{
		p=2*dx-dy;
		if(y1<y2)
		{
			y=y1;x=x1;end=y2;
			if(x1<x2)inc=1;
			if(x1>x2)inc=-1;
		}
		else
		{
			y=y2;x=x2;end=y1;
			if(x2<x1)inc=1;
			if(x2>x1)inc=-1;
		}
		while(y<=end)
  		{
 			putpixel(x,y,15);

 			if(p<0)p=p+2*dx;
 			else
 			{
 				x=x+inc;p=p+2*(dx-dy);
   			}
   			y++;
   			
  		}
 	}
}

int main()
{
	float x1,x2,y1,y2;
	int ch;
        cout<<"Enter the end points of line(x1,y1,x2,y2)"<<endl;
        cin>>x1>>y1>>x2>>y2;
        cout<<"Choose the alogorithm(1-DDA 2-BRESENHAM)";	
	cin>>ch;
//	printf("Enter end points of line(x1,y1,x2,y2)");
//	scanf("%f%f%f%f",&x1,&y1,&x2,&y2);
//	printf("Choose Algorithm(1-DDA 2-BRESENHAM)");
//	scanf("%d",&ch);
	int gd=DETECT,gm=0;
	initgraph(&gd,&gm,(char*)"");
	
	if(ch==1)
	dda(x1,y1,x2,y2);
	if(ch==2)
	bress(x1,y1,x2,y2);
	getch();
	closegraph();
	return 0;
}
