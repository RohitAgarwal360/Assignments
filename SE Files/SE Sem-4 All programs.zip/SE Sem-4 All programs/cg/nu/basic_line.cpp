#include<graphics.h>
#include<iostream>
#include<stdlib.h>
//#include<windows>
using namespace std;
class pixel
{
 int x,y;
  public:
           pixel()
           {
             x=0;
             y=0;           
            }
  
  void getdata();
  void display();
};
  
  void pixel::getdata()
  {
   cout<<"\n Enter x co ordinate:";
   cin>>x;
   cout<<"\n Enter y co ordinate:";
  cin>>y;
  }
   
   void pixel:: display()
   {
     cleardevice();
     setbkcolor(8);
     putpixel(x+1,y,GREEN);
  // setpixel(integer(x),integer(y));
     putpixel(x+3,y,GREEN);
     putpixel(x,y+4,RED);
     putpixel(x+3,y,GREEN);
     putpixel(x,y+2,RED);
     putpixel(x+1,y,GREEN);
  // putpixel(x,y+8,GREEN);
     circle(200,200,50);
     line(300,100,200,200);
     line(300,100,400,200);
     line(200,200,400,200);
     rectangle(40,90,90,40);
     outtextxy(x+10,y+10,(char *)"<-Required Point");
   }
   
   int main()
   {
    pixel obj;
    obj.getdata();
    int gd=DETECT,gm=0;
    initgraph(&gd,&gm,(char *)" ");
    obj.display();
    getch();
    closegraph();
   return 0;
   }
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   

