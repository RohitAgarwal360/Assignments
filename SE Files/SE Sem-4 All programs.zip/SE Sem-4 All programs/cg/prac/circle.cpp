 #include<iostream>
#include<graphics.h>
#include<termios.h>
#include<math.h>
using namespace std;
class pixel
 {
   public:
          void myputpixel(int x,int y)
          {
          	delay(20);
          	putpixel(x,y,RED);
          }
          
          void myputpixel(int x,int y,int color)
          {
          	putpixel(x,y,color);
          }
 };


class cir: public pixel
{
public:
  float d,x,y,r,x1,y1;
  
 
   void getdata();
   void brecircle();
   
};
 
void cir :: getdata()
 {
     cout<<"Enter centre x y =";
     cin>>x>>y;
     cout<<"Enter radius =";
     cin>>r;
     
     
 } 
 
 void cir::brecircle()
 {
	d=3-2*r;
	x1=0,y1=r;
	myputpixel(x,y);
	do
	{
	if(d<0)
	{
	 d=d+4*x1+6;
	}
	else
	{
	 d=d+4*(x1-y1)+10;
	 y1=y1-1;
	}
	x1=x1+1;
	
	myputpixel(x+x1,y+y1);
	myputpixel(x+x1,y-y1);
	myputpixel(x-x1,y+y1);
	myputpixel(x-x1,y-y1);
	myputpixel(x+y1,y+x1);
	myputpixel(x+y1,y-x1);
	myputpixel(x-y1,y+x1);
	myputpixel(x-y1,y-x1);
	
	}
	while(x1<=y1);
 } 
 
 int main()
  {
     cir obj;
     obj.getdata();
     int gd,gm;
     detectgraph(&gd,&gm);
     initgraph(&gd,&gm,(char *)" ");
     obj.brecircle();
     getch();
     closegraph();
     return 0;
    } 
     
