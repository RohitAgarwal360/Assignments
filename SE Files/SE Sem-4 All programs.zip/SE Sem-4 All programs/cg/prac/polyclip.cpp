#include<iostream>
#include<termios.h>
#include<math.h>
#include<graphics.h>
using namespace std;
#define round(a) ((int)(a+0.5))

 class clip
  {
   public:
     int k;
     float arr[100],m;
     int xmax,ymax,xmin,ymin; 
      void clipl(float x1,float y1,float x2,float y2);
      void clipt(float x1,float y1,float x2,float y2);
      void clipb(float x1,float y1,float x2,float y2);
      void clipr(float x1,float y1,float x2,float y2);
      void getdata();
   };
   void clip :: getdata()
 {
     cout<<"Enter xmin ymin xmax ymax =";
     cin>>xmin>>ymin>>xmax>>ymax;
    
     
  }
  
  void clip:: clipl(float x1,float y1,float x2,float y2)
  {
      if(x2-x1)
       {
         m=(y2-y1)/(x2-x1);
       }
      else
      {
        m=10000;
      }
      
      if(x1>=xmin && x2>=xmin)
      {
      	arr[k]=x2;
      	arr[k+1]=y2;
      	k=k+2;
      }
      if(x1>=xmin && x2<xmin)
      {
      	arr[k]=xmin;
      	arr[k+1]=y1+m*(xmin-x1);
      	k=k+2;
      }
      if(x1<xmin && x2>=xmin)
      {
        arr[k]=xmin;
        arr[k+1]=y1+m*(xmin-x1);
      	arr[k+2]=x2;
      	arr[k+3]=y2;
      	k=k+4;
      }
    }
    void clip:: clipr(float x1,float y1,float x2,float y2)
  {
      if(x2-x1)
       {
         m=(y2-y1)/(x2-x1);
       }
      else
      {
        m=1000000;
      }
      
      if(x1<=xmax && x2<=xmax)
      {
      	arr[k]=x2;
      	arr[k+1]=y2;
      	k=k+2;
      }
      if(x1>xmax && x2<=xmax)
      {
        arr[k]=xmax;
        arr[k+1]=y1+m*(xmax-x1);
      	arr[k+2]=x2;
      	arr[k+3]=y2;
      	k=k+4;
      }
      if(x1<=xmax && x2>xmax)
      {
      	arr[k]=xmax;
      	arr[k+1]=y1+m*(xmax-x1);
      	k=k+2;
      }
      
    }
    
    void clip:: clipb(float x1,float y1,float x2,float y2)
  {
      if(y2-y1)
       {
         m=(x2-x1)/(y2-y1);
       }
      else
      {
        m=10000;
      }
      
      if(y1>=ymin && y2>=ymin)
      {
      	arr[k]=x2;
      	arr[k+1]=y2;
      	k=k+2;
      }
      if(y1>=ymin && y2<ymin)
      {
      	arr[k]=x1+m*(ymin-x1);
      	arr[k+1]=ymin;
      	k=k+2;
      }
      if(y1<ymin && y2>=ymin)
      {
        arr[k]=x1+m*(ymin-x1);
        arr[k+1]=ymin;
      	arr[k+2]=x2;
      	arr[k+3]=y2;
      	k=k+4;
      }
    }
    
    
    void clip:: clipt(float x1,float y1,float x2,float y2)
  {
      if(y2-y1)
       {
         m=(x2-x1)/(y2-y1);
       }
      else
      {
        m=10000;
      }
      
      if(y1<=ymax && y2<=ymax)
      {
      	arr[k]=x2;
      	arr[k+1]=y2;
      	k=k+2;
      }
      if(y1<=ymax && y2>ymax)
      {
      	arr[k]=x1+m*(ymax-x1);
      	arr[k+1]=ymax;
      	k=k+2;
      }
      if(y1>ymax && y2<=ymax)
      {
        arr[k]=x1+m*(ymax-x1);
        arr[k+1]=ymax;
      	arr[k+2]=x2;
      	arr[k+3]=y2;
      	k=k+4;
      }
    }
    
   int main()
   {
   	int poly[100],n,i=0;
   	float polyy[100];
   	clip obj;
   	obj.getdata();
   	cout<<"Enter the number of sides = ";
   	cin>>n;
   	cout<<"Enter the sides = ";
   	for( i=0;i<2*n;i++)
   	{
   	   cout<<i+1<<"=";
   	   cin>>polyy[i];	
   	}
   	polyy[i]=polyy[0];
   	polyy[i+1]=polyy[1];
   	
   	
   	int gd,gn;
  	detectgraph(&gd,&gn);
   	initgraph(&gd,&gn,(char*)" ");
   	rectangle(obj.xmin,obj.ymax,obj.xmax,obj.ymin);
   	//fillpoly(n,poly);
   	
   	delay(500);
   	cleardevice();
    obj.k=0;
    for(i=0;i < 2*n;i+=2)
		obj.clipl(polyy[i],polyy[i+1],polyy[i+2],polyy[i+3]);
    n=obj.k/2;
    cout<<"k->"<<obj.k<<endl;
    for(i=0;i < obj.k;i++)
		polyy[i]=obj.arr[i];
    polyy[i]=polyy[0];
    polyy[i+1]=polyy[1];
    
    obj.k=0;
    for(i=0;i < 2*n;i+=2)
		obj.clipt(polyy[i],polyy[i+1],polyy[i+2],polyy[i+3]);
    n=obj.k/2;
    cout<<"k->"<<obj.k<<endl;
    for(i=0;i < obj.k;i++)
		polyy[i]=obj.arr[i];
    polyy[i]=polyy[0];
    polyy[i+1]=polyy[1];
    obj.k=0;
    for(i=0;i < 2*n;i+=2)
		obj.clipr(polyy[i],polyy[i+1],polyy[i+2],polyy[i+3]);
    n=obj.k/2;
    cout<<"k->"<<obj.k<<endl;
    for(i=0;i < obj.k;i++)
		polyy[i]=obj.arr[i];
    polyy[i]=polyy[0];
    polyy[i+1]=polyy[1];
    obj.k=0;
    for(i=0;i < 2*n;i+=2)
		obj.clipb(polyy[i],polyy[i+1],polyy[i+2],polyy[i+3]);
    for(i=0;i < obj.k;i++)
		poly[i]=round(obj.arr[i]);
    cout<<"k->"<<obj.k<<endl;
    if(obj.k)
		fillpoly(obj.k/2,poly);
   	rectangle(obj.xmin,obj.ymax,obj.xmax,obj.ymin);
   	
   	delay(500);
   	getch();
   	closegraph();
   	return 0;
   	
   }
