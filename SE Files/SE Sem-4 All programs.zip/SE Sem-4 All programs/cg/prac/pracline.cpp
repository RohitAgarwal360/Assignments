#include<iostream>
#include<graphics.h>
#include<termios.h>
#include<math.h>
using namespace std;
class pixel
 {
   public:
          void myputpixel(int x,int y)
          {
          	putpixel(x,y,RED);
          }
          
          void myputpixel(int x,int y,int color)
          {
          	putpixel(x,y,color);
          }
 };


class dda: public pixel
{
public:
  float x1,y1,x2,y2,dx,dy,steps,x,y;
  
 
   void getdata();
   void ddaline();
   void ddaline(float,float,float,float);

};

void dda :: getdata()
 {
     cout<<"Enter x1 y1 x2 y2 =";
     cin>>x1>>y1>>x2>>y2;
      y1=-y1;
     y2=-y2;
    
  }

void dda :: ddaline()
 {
 	//line(x1+220,y1+220,x2+220,y2+220);
    dx=x2-x1;
    dy=y2-y1;
     if(abs(dx)>=abs(dy))
      steps=abs(dx);
     else
      steps=abs(dy);
      
     x=x1;
     y=y1;
     myputpixel(x,y);
      for(int i=0; i<steps; i++)
       {
          x=x+(dx/steps);
          y=y+(dy/steps);
          
          myputpixel(x,y);
          
       }  
 
 }      
 
class bre: public pixel
{
public:
  int steps,x1,y1,x2,y2,dx,dy,p,x,y,inc;
  
 
   void getdata();
  void bres();
   

};

void bre :: getdata()
 {
     cout<<"Enter x1 y1 x2 y2 =";
     cin>>x1>>y1>>x2>>y2;
    
     
  }
void bre::bres()
{
    
    dx=abs(x2-x1);
    dy=abs(y2-y1);
    
    
    if(dx>dy)
    {
	p=2*dy-dx;
	if(x1<x2)
	{
	    	x=x1;
	    	y=y1;
	    	if(y2<y1)
		{
		    	inc = -1;
		}
    		else
    		{
    			inc = 1;
    		}
	}
    	else
    	{
    		x=x2;
    		y=y2;
    		if(y1<y2)
		{
		    	inc = -1;
		}
    		else
    		{
    			inc = 1;
    		}
    	}
    	
    	for(steps=0;steps<=abs(x2-x1);steps++)
    	{
   	 	if(p<0)
     		{
     		 p=p+2*dy;
     		}  
     		else
    		{
  		   	p=p+2*(dy-dx);
  		   	y=y+inc;
     		}
    		x=x+1;
    		myputpixel(x,y);
    	}
    }
    else
    {
   	p=2*dx-dy;
	if(y1<y2)
	{
	    	x=x1;
	    	y=y1;
	    	if(x2<x1)
		{
		    	inc = -1;
		}
    		else
    		{
    			inc = 1;
    		}
	}
    	else
    	{
    		x=x2;
    		y=y2;
    		if(x1<x2)
		{
		    	inc = -1;
		}
    		else
    		{
    			inc = 1;
    		}
    	}
    	
    	for(steps=0;steps<=abs(y2-y1);steps++)
    	{
   	 	if(p<0)
     		{
     		 p=p+2*dx;
     		}  
     		else
    		{
  		   	p=p+2*(dx-dy);
  		   	x=x+inc;
     		}
    		y=y+1;
    		myputpixel(x,y);
    	}
    }
}

void quadrants()
{	dda obj;
	obj.getdata();
	int xmax,ymax;
	  int gd,gm;
     detectgraph(&gd,&gm);
     initgraph(&gd,&gm,(char *)" ");
	xmax=getmaxx();
	ymax=getmaxy();
	
	obj.ddaline(xmax/2,0,xmax/2,ymax); //vertical line
	obj.ddaline(0,ymax/2,xmax,ymax/2); //horizotal line
	
	obj.ddaline((xmax/2)+obj.x1,(ymax/2)+obj.y1,(xmax/2)+obj.x2,(ymax/2)+obj.y2);
}

void dda :: ddaline(float x1,float y1,float x2,float y2 )
 {
 	//line(x1+220,y1+220,x2+220,y2+220);
    dx=x2-x1;
    dy=y2-y1;
     if(abs(dx)>=abs(dy))
      steps=abs(dx);
     else
      steps=abs(dy);
      
     x=x1;
     y=y1;
     myputpixel(x,y);
      for(int i=0; i<steps; i++)
       {
          x=x+(dx/steps);
          y=y+(dy/steps);
          delay(20);
          myputpixel(x,y);
          
       }  
 
 }      
 int main()
  {  dda obj;
	obj.getdata();
	cout<<"Enter the ";
     int gd,gm;
     detectgraph(&gd,&gm);
     initgraph(&gd,&gm,(char *)" ");
  
   
    // quadrants();
     getch();
     closegraph();
     return 0;
    } 
     
