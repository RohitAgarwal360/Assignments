import java.io.*;
class xyz {
public static void main (String []args) 
{

int x=50,y=70;
if(x==y)
{
System.out.println("x and y are same");
}

else
{
System.out.println ("x and y are different");
}

}
}
