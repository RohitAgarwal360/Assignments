public class obj {
	String name;
	int addr;
	obj(String nm, int address)
	{
		this.name=nm;
		this.addr=address;
	}
}