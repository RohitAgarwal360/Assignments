import java.lang.*;
import java.util.*;

class Banker {

Scanner sc = new Scanner (System.in);

private int  np, nr;

private int allo[][] , max[][] , need[][];

private int avai[];
void input () {

System.out.println("Enter the no of process: ");
np = sc.nextInt();

System.out.println("Enter the no of resources: ");
nr = sc.nextInt();

allo = new int [np][nr]; 
max = new int [np][nr];
need = new int [np][nr];
avai = new int [nr];

System.out.println("Enter the allocation matrix: ");

for(int i = 0 ; i < np ; i++){
	
	for (int j = 0 ; j < nr ; j++){
	
		allo[i][j] = sc.nextInt();
		
	}

}
System.out.println("Enter the max matrix: ");

for(int  i = 0 ; i < np ; i++){
	
	for (int j = 0 ; j < nr ; j++){
	
		max[i][j] = sc.nextInt();
		
	}

}

System.out.println("Enter the available matrix: ");

for (int i = 0 ; i < nr; i++)
{
avai[i]= sc.nextInt();

}

}


void calc_need() {

for( int i = 0 ; i <np;i++){

	for (int j =0 ;j<nr; j++){
	//max- allocation
	need[i][j]=max[i][j]-allo[i][j];
	System.out.print(need[i][j]+" ");
	
	}
	System.out.println();
	
}

}

boolean check(int k){

	for(int i=0 ; i < nr ; i++)
	{
		if (need[k][i]>avai[i])
		return false;
	}
return true;
}

/*
boolean check(int i ) {

	for(j=0 ; j < nr ; j++)
	{
	  if (avai[j]<need[i][j])
	  		return false;
	} 
	
	return true;	
		
}
*/


void safe() {

boolean done [] = new boolean [np];

boolean allocated;

int j=0;


while (j<np){

allocated = false;
	for(int i=0;i<np;i++){
		
		if(!done[i] && check(i))
			{
				for (int k=0 ; k<nr ; k++){	
					avai[k] += allo[i][k];
					}
				
				done[i]=allocated=true;
				System.out.println("allocated process"+(i+1));
				j++;
			
			}
		}

if (allocated==false)
 break;

}

if (j==np){
System.out.println("safe");
}
else{

System.out.println("not safe");
}

}







public static void main(String args []){

Banker br = new Banker();

br.input();
br.calc_need();
br.safe();


}



}

