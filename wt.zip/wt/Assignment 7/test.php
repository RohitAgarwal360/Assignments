test.php
-----------------------------------------------------------------------------------

<?php
include_once("db.php");

$number1=$_POST['num1'];
$number2=$_POST['num2'];

echo $number1 + $number2 ;

?>
